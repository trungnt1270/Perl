<?php
// Initiate parameters and values
{
	date_default_timezone_set("Asia/Ho_Chi_Minh");

	$today 		= date('Y-m-d');
	$today_full	= date('Y-m-d H:i:s');
	$yesterday 	= date('Y-m-d',strtotime("-1 days"));
	$lastmonth 	= date('Y-m-d',strtotime("-30 days"));
	$selfdomain = "https://". $_SERVER['SERVER_NAME'];
	$userip = real_ip();
	
	$url = "$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
	$urldecode = urldecode($url);
	// $data['url'] = $urldecode;
	// var_dump(parse_url($url, PHP_URL_QUERY));
	// die();
}
/*
	$lastquerytime = read_last_cdr_query();
	if (time() - strtotime($lastquerytime) < 60)	{
		$data['logmsg'] = "Too many query cdr request from '$userip' in request: $urldecode";
		$data['header'] = 'HTTP/1.0 400 Bad Request';
		$data['diemsg'] = "Too many request! Due to prevent the performance overload, this action is limited to 1 (one) request per minute. Please wait until " . date('Y-m-d h:i:s', strtotime($today_full) + 60) . ". Sorry for the inconvenience!";
		write_cdr_query_log_and_die($data);
	}
*/
//	Authenticate vnsale
{
	$valid_passwords = array ("ktnn" => "Aha7s3i8f^h8Di2$7");
	$valid_users = array_keys($valid_passwords);

	$user = $_SERVER['PHP_AUTH_USER'];
	$pass = $_SERVER['PHP_AUTH_PW'];

	$validated = (in_array($user, $valid_users)) && ($pass == $valid_passwords[$user]);

	if (!$validated) {
		writelog("Unauthorized request: $user / $pass for url: $urldecode");
		write_cdr_query_log();
		header('WWW-Authenticate: Basic realm="ITY CallCenter API"');
		header('HTTP/1.0 401 Unauthorized');
		die ("Invalid Username or Password");
	}
}

$post_actions 	= array("webhook_cdr_register", "webhook_missedcall_register");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$data = json_decode(file_get_contents('php://input'), true);
	if (json_last_error() !== JSON_ERROR_NONE) {
		writelog("Bad request - Could not decode JSON");
		header('HTTP/1.0 400 Bad Request');
		die('Could not decode JSON');
	}
	if (empty($data))	{
		writelog("Bad request - No POST Data");
		header('HTTP/1.0 400 Bad Request');
		die ("No data");
	}
	if (!isset($data['action']) || !in_array($data['action'], $post_actions))	{
		writelog("Bad request - Missing action in request: " . json_encode($data));
		header('HTTP/1.0 400 Bad Request');
		die ("Missing action in request");
	}

	call_user_func_array($data['action'], array($data));
	die("Unknown Error");
}

$actions 	= array("query_cdr", "query_misscall");
$flags 		= array("all", "new", "old");

// DB config and connect
{
$dbhost = "localhost";
$dbuser = "scriptuser";
$dbpass = "myroot#";
$dbname = "asteriskcdrdb";

// $dbconnstring = "host=$dbhost port=3306 dbname=$dbname user=$dbuser password=$dbpass options='--client_encoding=UTF8'";
// Connect MySQL
	$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
	
	/*
$conn = pg_connect($dbconnstring);
$dbstat = pg_connection_status($conn);
	if ($dbstat !== PGSQL_CONNECTION_OK || !$conn) {
		$data['logmsg'] = "DB Connection Failed, for '$userip' in request: $urldecode";
		$data['header'] = 'HTTP/1.0 500 Internal Server Error';
		$data['diemsg'] = "Err: DB error";
		write_cdr_query_log_and_die($data);
	} */  
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
	if (isset($_REQUEST['action']))	{
		$data['action'] = strtolower(trim(urldecode($_REQUEST['action'])));
		if (!in_array($data['action'], $actions))	{
			$data['logmsg'] = "Bad request - Missing action in request: $urldecode";
			$data['header'] = 'HTTP/1.0 400 Bad Request';
			$data['diemsg'] = "Invalid action in request";
			write_cdr_query_log_and_die($data);
		}
	} else {
		$data['action'] = "query_cdr";
	}

	if (isset($_REQUEST['flag']))	{
		// echo ($_REQUEST['flag']);
		$data['flag'] = strtolower(trim(urldecode($_REQUEST['flag'])));
		if (!in_array($data['flag'], $flags))	{
			$data['logmsg'] = "Bad request - Invalid flag: $urldecode";
			$data['header'] = 'HTTP/1.0 400 Bad Request';
			$data['diemsg'] = "Invalid flag";
			write_cdr_query_log_and_die($data);
		}
	} else {
		$data['flag'] = "new";
	}

// AccountCode processing
	if (isset($_REQUEST['accountcode'])){
		// echo ($_REQUEST['accountcode']);
		$data['accountcode'] = trim(urldecode($_REQUEST['accountcode']));
		$accountcode = preg_replace('~[^0-9a-z\\s]~i', '', $data['accountcode']);
		if ($accountcode !== $data['accountcode'] || strlen($accountcode) > 20 || strlen($accountcode) < 3)	{
			$data['logmsg'] = "Invalid accountcode - $urldecode";
			$data['header'] = 'HTTP/1.0 400 Bad Request';
			$data['diemsg'] = "Invalid accountcode";
			write_cdr_query_log_and_die($data);
		}
		// $accountcode = mysqli_real_escape_string($accountcode);

		// Get accountcode information
		$sql = "select * from asteriskcdrdb.cdr where accountcode = '$accountcode'";
		$result = $conn->query($sql);
		// $result = pg_query($conn, $sql);
		if (!$result) {
			$data['logmsg'] = "DB error, failed to select accountcode: '$accountcode' - $urldecode";
			$data['header'] = 'HTTP/1.0 500 Internal Server Error';
			$data['diemsg'] = "Unable to check AccountCode information! Please check your Administrator!";
			write_cdr_query_log_and_die($data);
		}
		if (mysqli_num_rows($result) > 0) {
			while ($row = $result->fetch_assoc()) {
				$accountinfo = $row;
			}
		} else {
			$data['logmsg'] = "Accountcode '$accountcode' does not exist - $urldecode";
			$data['header'] = 'HTTP/1.0 400 Bad Request';
			$data['diemsg'] = "AccountCode '$accountcode' does not exist!";
			write_cdr_query_log_and_die($data);
		}
	}else{
		$data['logmsg'] = "AccountCode is required!";
			$data['header'] = 'HTTP/1.0 400 Bad Request';
			$data['diemsg'] = "AccountCode is required!";
			write_cdr_query_log_and_die($data);
	}

// Extension processing
	if (isset($_REQUEST['extension']))	{
		$data['extension'] = trim(urldecode($_REQUEST['extension']));
		// $extension = preg_replace('/\D/', '', $data['extension']);
		$extension = $_REQUEST['extension'];
		if ($extension !== $data['extension'] || strlen($extension) > 6 || strlen($extension) < 4)	{
			$data['logmsg'] = "Invalid extension - $urldecode";
			$data['header'] = 'HTTP/1.0 400 Bad Request';
			$data['diemsg'] = "Invalid extension";
			write_cdr_query_log_and_die($data);
		}
		// $extension = mysqli_real_escape_string($extension);

		// Get extension information
		$sql = "select * from asterisk.devices e
		LEFT JOIN asteriskcdrdb.cdr C ON e.id = C.dst
		LEFT JOIN asteriskcdrdb.cdr V ON e.id = V.src
		where e.id = '$extension'";
		if (isset($accountcode))	$sql .= " and V.accountcode = '$accountcode'";
		// echo($sql);
		// $result = pg_query($conn, $sql);
		$result = $conn->query($sql);
		if (!$result) {
			$data['logmsg'] = "DB error, failed to select extension: '$extension' - $urldecode";
			$data['header'] = 'HTTP/1.0 500 Internal Server Error';
			$data['diemsg'] = "Unable to check Extension information! Please check your Administrator!";
			write_cdr_query_log_and_die($data);
		}
		if (mysqli_num_rows($result) > 0) {
			while ($row = $result->fetch_assoc()) {
				$extinfo = $row;
			}
		} else {
			if (isset($accountcode))	{
				$data['logmsg'] = "Extension '$extension' does not exist for customer $accountcode - $urldecode";
				$data['diemsg'] = "Extension '$extension' does not exist for customer $accountcode!";
			} else	{
				$data['logmsg'] = "Extension '$extension' does not exist - $urldecode";
				$data['diemsg'] = "Extension '$extension' does not exist!";
			}
			$data['header'] = 'HTTP/1.0 400 Bad Request';
			write_cdr_query_log_and_die($data);
		}
	}

// aleg processing
	if (isset($_REQUEST['aleg']))	{
		// $data['aleg'] = trim(urldecode($_REQUEST['aleg']));
		// $aleg = preg_replace('/\D/', '', $data['aleg']);
		$aleg = $_REQUEST['aleg'];
		// print_r($_REQUEST['aleg']);
		if ($aleg !== $_REQUEST['aleg'] || strlen($aleg) > 22 || strlen($aleg) < 18)	{
			$data['logmsg'] = "Invalid aleg - $urldecode";
			$data['header'] = 'HTTP/1.0 400 Bad Request';
			$data['diemsg'] = "Invalid aleg!";
			write_cdr_query_log_and_die($data);
		}
		// $aleg = mysqli_real_escape_string($aleg);
	}
// Phone processing
	if (isset($_REQUEST['phone']))	{
		$data['phone'] = trim(urldecode($_REQUEST['phone']));
		$phone = preg_replace('/\D/', '', $data['phone']);
		if ($phone !== $data['phone'] || strlen($phone) > 11 || strlen($phone) < 4)	{
			$data['logmsg'] = "Invalid Phone Number - $urldecode";
			$data['header'] = 'HTTP/1.0 400 Bad Request';
			$data['diemsg'] = "Invalid Phone Number!";
			write_cdr_query_log_and_die($data);
		}
		// $phone = mysqli_real_escape_string($phone);
	}

// Date processing
	if (isset($_REQUEST['date']))	{
		$data['date'] = trim(urldecode($_REQUEST['date']));
		$date = date_create_from_format('Y-m-d', $data['date']);
		if (!$date)	{
			$data['logmsg'] = "Invalid Date Format - $urldecode";
			$data['header'] = 'HTTP/1.0 400 Bad Request';
			$data['diemsg'] = "Invalid Date Format! Accepted format is 'Y-m-d'.";
			write_cdr_query_log_and_die($data);
		}
		$date 		= date_format($date, 'Y-m-d');
		$fromdate 	= $date . " 00:00:00";
		$todate 	= $date . " 23:59:59";
	}/*
	else {
		$fromdate	= $today . " 00:00:00";
		$todate 	= $today . " 23:59:59";
	}*/

// From Date processing
	if (!isset($date) && isset($_REQUEST['fromdate']))	{
		$data['fromdate'] = trim(urldecode($_REQUEST['fromdate']));
		$fromdate = date_create_from_format('Y-m-d H:i:s', $data['fromdate']);
		if (!$fromdate)	{
			$fromdate = date_create_from_format('Y-m-d', $data['fromdate']);
			if (!$fromdate)	{
				$data['logmsg'] = "Invalid From Date Format - $urldecode";
				$data['header'] = 'HTTP/1.0 400 Bad Request';
				$data['diemsg'] = "Invalid From Date Format! Accepted format is  'Y-m-d' or 'Y-m-d H:i:s'.";
				write_cdr_query_log_and_die($data);
			}
			$fromdate 	= date_format($fromdate, 'Y-m-d');
			$fromdate 	= $fromdate . " 00:00:00";
			$todate 	= $today . " 23:59:59";
		} else {
			$fromdate 	= date_format($fromdate, 'Y-m-d H:i:s');
			$todate 	= $today . " 23:59:59";
		}
	}

// To Date processing
	if (!isset($date) && isset($_REQUEST['fromdate']) && isset($_REQUEST['todate']))	{
		$data['todate'] = trim(urldecode($_REQUEST['todate']));
		$todate = date_create_from_format('Y-m-d H:i:s', $data['todate']);
		if (!$todate)	{
			$todate = date_create_from_format('Y-m-d', $data['todate']);
			if (!$todate)	{
				$data['logmsg'] = "Invalid To Date Format - $urldecode";
				$data['header'] = 'HTTP/1.0 400 Bad Request';
				$data['diemsg'] = "Invalid To Date Format! Accepted format is  'Y-m-d' or 'Y-m-d H:i:s'.";
				write_cdr_query_log_and_die($data);
			}
			$todate 	= date_format($todate, 'Y-m-d');
			$todate 	= $todate . " 23:59:59";
		} else {
			$todate 	= date_format($todate, 'Y-m-d H:i:s');
		}
		if (new DateTime($fromdate) > new DateTime($todate))	{
				$data['logmsg'] = "From Date is after To Date - $urldecode";
				$data['header'] = 'HTTP/1.0 400 Bad Request';
				$data['diemsg'] = "From Date is after To Date.";
				write_cdr_query_log_and_die($data);
		}
	}

// echo $fromdate;
// echo $todate;

// Limit processing
	if (isset($_REQUEST['limit']))	{
		$limit = preg_replace('/\D/', '', trim(urldecode($_REQUEST['limit']))) * 1;
		if ($limit  < 0 || $limit > 1000)	{
			$limit = 1000;
		}
		$data['limit'] = $limit;
	} else {
		$limit = 20;
	}
// Limit processing
	if (isset($_REQUEST['offset']))	{
		$offset = preg_replace('/\D/', '', trim(urldecode($_REQUEST['offset']))) * 1;
		if ($offset  < 0 || $offset > 1000)	{
			$offset = 1000;
		}
		$data['offset'] = $offset;
	} else {
		$offset = 0;
	}


	// Get cdr Inbox
	/*
	$sql = "SELECT C.accountcode, C.direction, C.extension_uuid, C.caller_id_name, C.caller_id_number, C.caller_destination, C.destination_number,
C.start_stamp, C.answer_stamp, C.end_stamp, C.duration, C.billsec, C.record_path, C.record_name, C.missed_call, 
C.hangup_cause, C.hangup_cause_q850, C.sip_hangup_disposition, C.apiread, C.xml_cdr_uuid,
E.accountcode AS extaccountcode, E. outbound_caller_id_name
FROM v_xml_cdr C
LEFT JOIN v_extensions E ON E.extension = C.caller_destination
LEFT JOIN v_extensions X ON X.extension = C.caller_id_number
";
*/


// bỏ lastapp lastdata dcontext channel dstchannel amaflag uniqueid outbound_cnum outbound_cnam  dst_cnam did

	$sql ="SELECT C.calldate, C.clid, C.src, C.dst, 
 C.duration, C.billsec, C.disposition,C.accountcode, C.userfield, C.recordingfile,
  C.apiread, E.description, C.cnam, C.cnum, C.lastapp, C.uniqueid
FROM asteriskcdrdb.cdr C
LEFT JOIN asterisk.devices E ON E.id = C.dst
LEFT JOIN asterisk.devices X ON X.id = C.src
";

	$tsql = "SELECT count(*) as total
FROM asteriskcdrdb.cdr C
LEFT JOIN asterisk.devices E ON E.id = C.dst
LEFT JOIN asterisk.devices X ON X.id = C.src";


	$conditions = array();
	$conditions[] = "C.lastapp = 'Dial' AND C.disposition in ('ANSWERED','NO ANSWER','BUSY')";
	$conditions[] = "(C.accountcode = '$accountcode')";										 
	// $conditions[] = "C.accountcode = 'getfly' ";
	// $conditions[] = "C.billsec > 1 AND C.disposition = 'ANSWERED' AND C.lastapp = 'Dial'";
	// if ($data['action'] == 'query_misscall')
		// $conditions[] = "C.missed_call = true";
	
	
	if ($data['flag'] === "new")
		$conditions[] = "C.apiread = 0";
	else if ($data['flag'] === "old")
		$conditions[] = "C.apiread = 1";
	
	
	if (isset($aleg))
		$conditions[] = "(C.userfield = '$aleg')";
	if (isset($extension))
		$conditions[] = "(C.src = '$extension')";
	if (isset($phone))
		$conditions[] = "(C.dst = '$phone' OR C.src = '$phone' OR C.cnum = '$phone')";
	if (isset($fromdate))
		$conditions[] = "C.calldate > '$fromdate'";
	if (isset($todate))
		$conditions[] = "C.calldate < '$todate'";
	
	
	

	if (count($conditions) > 0) {
		$sql .= " WHERE " . implode(" AND ", $conditions);
		$tsql .= " WHERE " . implode(" AND ", $conditions);
	}
	$sql .= " ORDER BY C.calldate DESC LIMIT $limit OFFSET $offset";

// echo $sql;

	// $result = pg_query($conn, $sql);
	$result = $conn->query($sql);
	$totals = $conn->query($tsql);
	$totalz = $totals -> fetch_assoc();
	$total = $totalz['total'];
	
	// print_r($tsql);
	$cdrlist = array();
	$cdrlistupdate = array();
	$new = 0;
	$old = 0;
	if (!$result) {
		writelog("DB error, failed to select cdr: '$sql'");
		$conn -> close();
		header('HTTP/1.0 500 Internal Server Error');
		die ("Unable to query CDR! Please check your Administrator!");
	}
	if (mysqli_num_rows($result) > 0) {
		while ($row = $result -> fetch_assoc()) {
			$cdr = array();
			$cdr['uniqueid']	= $row['uniqueid'];
			$cdr['calldate']	= $row['calldate'];
			$cdr['clid'] 	= $row['clid'];
			$cdr['clid'] 	= $row['clid'];
			$cdr['src']	= $row['src'];
			$cdr['dst']	= $row['dst'];
			/*
			 $cdr['direction']	= $row['direction'];
			if ($cdr['direction'] == 'outbound')
				$cdr['destination_number']	= $row['destination_number'];
			else 
				$cdr['destination_number']	= $row['caller_destination'];
			
			$cdr['start_stamp']	= $row['start_stamp'];
			$cdr['answer_stamp']	= $row['answer_stamp'];
			$cdr['end_stamp']	= $row['end_stamp'];
			
			if ($row['missed_call'] == 'f') 
				$cdr['missed_call']	= 'false';
			else 
				$cdr['missed_call'] = 'true';
			*/
			$cdr['duration']	= $row['duration'];
			$cdr['billsec']	= $row['billsec'];
			$cdr['disposition']	= $row['disposition'];
			$cdr['accountcode']	= $row['accountcode'];
			// $cdr['userfield']	= $row['userfield'];// callnumber|callid
			
			$userfield = $row['userfield'];
			$call = explode("|",$userfield);
			if(isset($call[1])){
				$cdr['call_id'] = $call[1];
				$cdr['call_number'] = $call[0];
			}
			
			// $cdr['channel'] = $row['channel'];
			
			
			// $cdr['description']	= $row['description'];
			$cdr['cnam']	= $row['cnam'];
			$cdr['cnum']	= $row['cnum'];
			
			$record_path	= $row['recordingfile'];
			$path = explode('/', $record_path);
			$i = count($path);
			// $cdr['recordingfile'] = "/". $path[3] . "/" . $path[2] . "/" $path[1] . "/" . $row['record_name'];
			// $cdr['recordingfile'] = var_dump($path);
			$cdr['recordingfile'] = "";
			// out-0904824242-2901-20210825-114630-1629866790.0.wav
			
			
			// $cdr['recordingfile'] = "/records/".date("Y")."/".date("m")."/".date("d")."/";
			// $cdr['recordingfile'] .= $row['recordingfile'];
			
			$cdr['recordingfile'] = $selfdomain."/records/?action=record&id=".$row['uniqueid'];
			
			
			
			$start_stamp = $cdr['calldate'];
			// if (date("n",strtotime($start_stamp)) * 1 > 5)
			// if (date("n",strtotime($start_stamp)) * 1 < 8)
				
				// $cdr['recordingfile'] .= date("Y-m-d", strtotime($start_stamp)) . "/";
			// $cdr['recordingfile'] .= "out-" . $cdr['dst'] . "-" . $cdr['src'] . "-" . date("Ymd") . "-" . date("His") . $cdr['uniqueid'] . ".wav";

			if ($row['apiread'] == 0)	{
				$cdr['status'] = 'NEW';
				$new++;
			} else {
				$cdr['status'] = 'OLD';
				$old++;
			}

			$cdrlist[] = $cdr;

			// if ($row['apiread'] == 0) $cdrlistupdate[] = $row['uniqueid'];
			if ($row['apiread'] == 0) $cdrlistupdate[] = $row['uniqueid'];
		}
	}

	if (count($cdrlistupdate) > 0)	{
		if (count($cdrlistupdate) > 1)	{
			$query = "UPDATE asteriskcdrdb.cdr SET apiread = 1 WHERE uniqueid IN ('" . implode("', '", $cdrlistupdate) . "')";
		} else {
			$query = "UPDATE asteriskcdrdb.cdr SET apiread = 1 WHERE uniqueid = '" . $cdrlistupdate[0] . "'";
		}
		// $result = pg_query($conn, $query);
		$result = $conn->query($query);
		if (!$result) {
			writelog("DB error, failed to update apiread for sql unread: '$query'");
			$conn -> close();
			header('HTTP/1.0 500 Internal Server Error');
			die ("Unable to update CDR status! Please check your Administrator!");
		}
	}

	$result = array("cdr" => $cdrlist);
	// $result["sql"] = $sql;
	$result["new"] = $new;
	$result["old"] = $old;
	$result["total"] = $total;
	write_cdr_query_log($data);
	die(json_encode($result));

}



// Get POST information
$data = json_decode(file_get_contents('php://input'), true);

// AccountCode processing
{
	if (!isset($data['accountcode'])) 	{
		writelog("AccountCode must be specified " . json_encode($data));
		$conn -> close();
		header('HTTP/1.0 400 Bad Request');
		die ("AccountCode must be specified!");
	}
	$accountcode = trim(preg_replace('~[^0-9a-z\\s]~i', '', $data['accountcode']));
	if ($accountcode !== $data['accountcode']  ||  strlen($accountcode) > 20)	{
		writelog("Invalid accountcode - " . json_encode($data));
		$conn -> close();
		header('HTTP/1.0 400 Bad Request');
		die ("Invalid AccountCode '" . $data['accountcode'] . "', compare to " . $accountcode . "!");
	}

	// Get accountcode information
	$sql = "select * from accountcode where accountcode = '$accountcode' and enabled = 1";
	// $result = pg_query($conn, $sql);
	$result = $conn->query($sql);
	if (!$result) {
		writelog("DB error, failed to select accountcode: '$accountcode' - " . json_encode($data));
		$conn -> close();
		header('HTTP/1.0 500 Internal Server Error');
		die ("Unable to check AccountCode information! Please check your Administrator!");
	}
	if (mysqli_num_rows($result) > 0) {
		while ($row = $result -> fetch_assoc()) {
			$account = $row;
		}
	} else {
		writelog("Accountcode does not exist - " . json_encode($data));
		$conn -> close();
		header('HTTP/1.0 400 Bad Request');
		die ("AccountCode '" . $accountcode . "' does not exist!");
	}
}

// Extension processing
{
	if (!isset($data['extension'])) 	{
		writelog("Extension must be specified " . json_encode($data));
		// pg_close($conn);
		$conn -> close();
		header('HTTP/1.0 400 Bad Request');
		die ("Extension must be specified!");
	}
	$extension = preg_replace('/\D/', '', $data['extension']);
	if ($extension !== $data['extension']  ||  strlen($extension) > 6)	{
		writelog("Invalid extension - " . json_encode($data));
		$conn -> close();
		header('HTTP/1.0 400 Bad Request');
		die ("Invalib Extension '" . $data['extension'] . "', compare to " . $extension . "!");
	}

	// Get extension information
	$sql = "select * from asteriskcdrdb.devices E where C.accountcode = '$accountcode' and E.id = '$extension'
	LEFT JOIN asterisk.cdr C ON E.id = C.src";
	// $result = pg_query($conn, $sql);
	$result = $conn->query($sql);
	if (!$result) {
		writelog("DB error, failed to select extension: '$extension' - " . json_encode($data));
		$conn -> close();
		header('HTTP/1.0 500 Internal Server Error');
		die ("Unable to check Extension information! Please check your Administrator!");
	}
	if (mysqli_num_rows($result) > 0) {
		while ($row = $result->fetch_assoc()) {
			$extinfo = $row;
		}
	} else {
		writelog("Extension does not exist - " . json_encode($data));
		$conn -> close();
		header('HTTP/1.0 400 Bad Request');
		die ("Extension '" . $extension . "' does not exist!");
	}
}

// Phone processing
{
	if (!isset($data['phone'])) 	{
		writelog("Phone number must be specified " . json_encode($data));
		// pg_close($conn);
		$conn -> close();
		header('HTTP/1.0 400 Bad Request');
		die ("Phone number must be specified!");
	}
	$phone = preg_replace('/\D/', '', $data['phone']);
	if ($phone !== $data['phone']  ||  strlen($phone) != 10)	{
		writelog("Invalid phone number - " . json_encode($data));
		// pg_close($conn);
		$conn -> close();
		header('HTTP/1.0 400 Bad Request');
		die ("Invalid Phone number '" . $data['phone'] . "', compare to " . $phone . "!");
	}
	$phoneprefix = substr($phone, 0, 3);
	if (!in_array($phoneprefix, $mobileprefix))	{
		writelog("Invalid phone number, not in Viettel, Mobifone, Vinaphone - " . json_encode($data));
		// pg_close($conn);
		$conn -> close();
		header('HTTP/1.0 400 Bad Request');
		die ("Phone number '" . $data['phone'] . "' must be Viettel or Mobifone or Vinaphone!");
	}
}

// Message processing
{
	if (!isset($data['message'])) 	{
		writelog("Message must be specified " . json_encode($data));
		// pg_close($conn);
		$conn -> close();
		header('HTTP/1.0 400 Bad Request');
		die ("Message must be specified!");
	}
	$message = trim(preg_replace('~[^\P{Cc}\r\n]+~u', '', $data['message']));
	if (strlen($message) == 0)	{
		writelog("Invalid Message " . json_encode($data));
		// pg_close($conn);
		$conn -> close();
		header('HTTP/1.0 400 Bad Request');
		die ("Invalid Message!");
	}
	if (strlen($message) > 256)	{
		writelog("Message too long" . json_encode($data));
		// pg_close($conn);
		$conn -> close();
		header('HTTP/1.0 400 Bad Request');
		die ("Message too long!");
	}
}

writelog("[" . $extension . "] send SMS to [" . $phone . "] with message '" . $message . "'");

// Initiate Destination configuration
{
	$cdr['sender']  	= $extension;
	$cdr['message']		= $message;
	$cdr['phone']		= $phone;
	$cdr['accountcode']	= $accountcode;

	$cdr['hash'] = hash('md5', $cdr['sender'] . $cdr['phone'] . $cdr['message']);
	$cdr['status'] = 0;
	$cdr['statusdesc'] = 'NEW';

	$gw['name'] = 'gsm508';
	$gw['ip']   = '192.168.8.58';
	$gw['user'] = $gw_default_username;
	$gw['pass'] = $gw_default_password;

	if (in_array($phoneprefix, $vtlprefix))	{
		$gw['port'] = 11;
	} else if (in_array($phoneprefix, $vmsprefix))	{
		$gw['port'] = 13;
	} else if (in_array($phoneprefix, $vnpprefix))	{
		$gw['port'] = 13;
	} else {
		writelog("Undefined destination port - " . json_encode($data));
		// pg_close($conn);
		$conn -> close();
		header('HTTP/1.0 500 Internal Server Error');
		die ("Undefined Destination! Please check your Administrator!");
	}
}


	$cdr['id'] = insert_cdr_to_db($conn, $cdr, $gw);
	if ( false===$cdr['id'] ) {
		// pg_close($conn);
		$conn -> close();
		header('HTTP/1.0 500 Internal Server Error');
		die ("Unable to enqueue SMS message! Please check your Administrator!");
	}

	$cdr = send_cdr_to_gw($cdr, $gw);

	if (isset($cdr['result']['error_code']) && $cdr['result']['error_code'] == 202)	{
		if (update_cdr($conn, $cdr))
			writelog("Update OK");
	}


	echo "Tin nhắn '" . $message . "' từ agent [" . $extension . "] đang được gửi tới " . $phone . "!";

// pg_close($conn);
$conn -> close();




function send_cdr_to_gw($cdr, $gw)	{

	$content = build_cdr_json($cdr, $gw);

	$url = 'http://' . $gw['ip'] . '/api/send_sms';
	$ch = curl_init($url);
	// $jsonDataEncoded = json_encode($data);
	//Tell cURL that we want to send a POST request.
	curl_setopt($ch, CURLOPT_POST, 1);
	 
	//Attach our encoded JSON string to the POST fields.
	// curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonDataEncoded);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $content);
	 
	//Set the content type to application/json
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json')); 

	// curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_USERPWD, $gw['user'] . ":" . $gw['pass']);
	curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);

	//Execute the request
	$result = curl_exec($ch);
	// $info = curl_getinfo($ch);

	writelog('cURL sent: ' .  $url . ' - ' . $content . ' - ' . $result);

	$cdr['result'] = json_decode($result, TRUE);

	return $cdr;
}

function build_cdr_json($cdr, $gw)	{
	$dest[] = array(
				"number" => $cdr['phone']
				// ,"text_param" => ""
				,"user_id" => $cdr['id']
			);
	$content = array(
		 "text" 	=> $cdr['message']
		,"port" 	=> array($gw['port'])
		,"encoding" => 'unicode'
		,"request_status_report" => 'true'
		,"param" 	=> $dest
	);
	return json_encode($content);
}

function insert_cdr_to_db(&$conn, $cdr, $gw)	{

	$sql = "SELECT hash FROM v_sms_outbox WHERE hash = '" . $cdr['hash'] . "' AND processing_time > '" . date('Y-m-d H:i:s', strtotime('-4 hour')) . "' ORDER BY processing_time DESC LIMIT 1";
	// writelog($query);
	// $result = pg_query($conn, $sql);
	$result = $conn->query($sql);
	if ($result  &&  mysqli_num_rows($result) > 0) {
		// pg_close($conn);
		$conn -> close();
		writelog($cdr['phone'] . " - Duplicated SMS Entry in the last 1 hour!");
		header('HTTP/1.0 429 Too Many Requests');
		die ("Duplicated SMS Entry in the last 1 hour!");
	}

	$phone_number	= mysqli_real_escape_string($cdr['phone']);
	$message 		= mysqli_real_escape_string($cdr['message']);
	$accountcode 	= mysqli_real_escape_string($cdr['accountcode']);
	$agent 			= mysqli_real_escape_string($cdr['sender']);
	$gw_name 		= mysqli_real_escape_string($gw['name']);
	$gw_ip 			= mysqli_real_escape_string($gw['ip']);
	$gw_port 		= mysqli_real_escape_string($gw['port']);
	$hash 			= mysqli_real_escape_string($cdr['hash']);
	$status 		= mysqli_real_escape_string($cdr['status']);
	$statusdesc 	= mysqli_real_escape_string($cdr['statusdesc']);
	$sql = "INSERT INTO v_sms_outbox
		(phone_number, 	  message, 	accountcode, 	agent, 	gw_name, 	gw_ip, 	gw_port, processing_time, 	sent_time, hash,   status,   statusdesc)
VALUES ('$phone_number','$message','$accountcode','$agent','$gw_name','$gw_ip','$gw_port',	NOW(),		NOW(),		 '$hash','$status','$statusdesc')
RETURNING id";

	// $result = pg_query($conn, $sql);
	$result = $conn->query($sql);

	if (!$result) {
		writelog($cdr['phone'] . " - DB Insert sms entry error! execute() failed: $sql - " . json_encode($cdr));
		// pg_close($conn);
		$conn -> close();
		header('HTTP/1.0 500 Internal Server Error');
		die ("Unable to enqueue SMS message! Please check your Administrator!");
	} else if (mysqli_num_rows($result) > 0) {
		while ($row = $result->fetch_assoc()) {
			$id = $row['id'];
		}
		return $id;
	}
}

function update_cdr(&$conn, $cdr)	{
	
	if (!isset($cdr['id']))	return false;

	$sql = "UPDATE v_sms_outbox SET";

	$construct = array();

	if (isset($cdr['result']['error_code']))	$construct[] = " gw_send_code = " .  $cdr['result']['error_code'];
	if (isset($cdr['result']['sms_in_queue']))	$construct[] = " gw_in_queue = " .  $cdr['result']['sms_in_queue'];
	if (isset($cdr['result']['task_id']))		$construct[] = " gw_task_id = " .  $cdr['result']['task_id'];

	if (empty($construct))	return false;

	$sql .= implode(", ", $construct);
	$sql .= " WHERE id = " . $cdr['id'];

	writelog($sql);
	// $result = pg_query($conn, $sql);
	$result = $conn->query($sql);

	if (!$result) {
		return false;
	}	else {
		return true;
	}
}

function writecdrlog($cdr, $strGatewayID)	{

	$_logfile = 'cdr.log';

	$fp = fopen($_logfile, 'a');	//opens file in append mode  
	fwrite($fp, "[" . $cdr['timestamp'] . "][" . $strGatewayID . "." . $cdr["port"] . "][ID:" . $cdr['incoming_sms_id'] . "][From:" . $cdr['number'] . "]" . $cdr['text'] . "\r\n" );  
	fclose($fp);  
	
}

function writelog($message)	{

	$_logfile = 'cdr.log';

	$fp = fopen($_logfile, 'a');	//opens file in append mode  
	fwrite($fp, '[' . date('Y-m-d H:i:s') . '] ' . $message . PHP_EOL);  
	fclose($fp);  
	
}

function real_ip()	{
   $ip = $_SERVER['REMOTE_ADDR'];
    if (isset($_SERVER['HTTP_X_FORWARDED_FOR']) && preg_match_all('#\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}#s', $_SERVER['HTTP_X_FORWARDED_FOR'], $matches)) {
        foreach ($matches[0] AS $xip) {
            if (!preg_match('#^(10|172\.16|192\.168)\.#', $xip)) {
                $ip = $xip;
                break;
            }
        }
    } elseif (isset($_SERVER['HTTP_CLIENT_IP']) && preg_match('/^([0-9]{1,3}\.){3}[0-9]{1,3}$/', $_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (isset($_SERVER['HTTP_CF_CONNECTING_IP']) && preg_match('/^([0-9]{1,3}\.){3}[0-9]{1,3}$/', $_SERVER['HTTP_CF_CONNECTING_IP'])) {
        $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
    } elseif (isset($_SERVER['HTTP_X_REAL_IP']) && preg_match('/^([0-9]{1,3}\.){3}[0-9]{1,3}$/', $_SERVER['HTTP_X_REAL_IP'])) {
        $ip = $_SERVER['HTTP_X_REAL_IP'];
    }
    return $ip;

}

function sendcdrmail($cdr)	{
	require("phpmailer/class.phpmailer.php"); // nạp thư viện gửi mail
	$mailer = new PHPMailer(); // khởi tạo đối tượng
	
	// Đăng nhập SMTP
	// Thiết lập SMTP Server
	$mailer->IsSMTP(); // gọi class smtp để đăng nhập

	// Thiết lập thông tin máy chủ mail
	$mailer->SMTPAuth 	= true; // gửi thông tin đăng nhập
	$mailer->SMTPSecure = "ssl";
	$mailer->Host       = "smtp.gmail.com";
	$mailer->Port       = 465;

	// Thông tin email client dùng để gửi
	$mailer->Username 	= 'ity.issabel.alert@gmail.com'; // tên đăng nhập
	$mailer->Password 	= "#ITY@2019*"; // mật khẩu
	$mailer->CharSet	="utf-8"; // bảng mã unicode

	// Chuẩn bị gửi thư nào
	$mailer->FromName 	= 'Issabel ITY SMS'; // tên người gửi
	$mailer->From 		= 'ity.issabel.alert@gmail.com'; // mail người gửi

	
	$mailer->AddAddress($cdr['email'], '');
	// $mailer->AddBCC("nguyenthihaiyen1204@gmail.com", 'Yến Nguyễn Thị Hải');
	// $mailer->AddAddress("nv.khoa.bk@gmail.com", 'Khoa Nguyễn Việt');
	// $mailer->AddBCC("khoa.nguyen.viet.2012@gmail.com", 'Khoa Nguyễn Việt');

	$sub = "[ITY-SMS] SMS mới từ số điện thoại " . $cdr['number'] . " vào lúc " . $cdr['timestamp'];
	$mailer->Subject = $sub;							// tiêu đề
	$mailer->IsHTML(true); //Bật HTML không thích thì false


	// Nhúng ảnh để hiển thị trong email bằng CSS hay HTML
	// $mailer->AddEmbeddedImage('images/hinh.jpg', 'logoimg', 'hinh.jpg'); //đính kèm và nhúng ảnh vào email

	// Nội dung lá thư
	$mailbody 	= "<h3>Kính chào quý khách hàng " . $cdr['accountcode']. "!</h3><br><br>";
	$mailbody  .= "Bạn có tin nhắn mới từ số điện thoại <b>" . $cdr['number'] . "</b> vào lúc <b>" . $cdr['timestamp'] . "</b> với nội dung:<br><br>";
	$mailbody  .= "<b>" . $cdr['text'] . "</b><br><br>";
	$mailbody  .= "Agent có số máy lẻ <b>" . $cdr['agent'] . "</b> là người gần nhất đã gọi đến khách hàng này vào lúc <b>" . $cdr['lastcall'] . "</b><br><br>";
	$mailbody  .= "Mọi chi tiết xin liên hệ group Zalo Support.<br>Xin trân trọng cảm ơn!";
	
	$mailer->Body = $mailbody;							// nội dung
	// $mailer->Body = "<h1>Một lá thư gửi bằng PHPMailer</h1>
	// <p>Đây là hình ta mới nhúng lúc nảy: <img src=\"cid:logoimg\" /></p>";

	// Gửi email

	if(!$mailer->Send())	{
		// Gửi không được, đưa ra thông báo lỗi
		echo "Mailer error: " . $mailer->ErrorInfo . "\r\n";
	}	else 	{
		echo "Mailer sent successfully!\r\n";
	}
}

function write_cdr_query_log($data = array())	{
	global $today_full;
	global $userip;
	$_logfile = 'cdr_audit.csv';

	// $audit = array($today_full, $userip, json_encode($data));

	$fp = fopen($_logfile, 'a');	//opens file in append mode  
	// fputcsv($fp, $audit);
	fwrite($fp, "[$today_full][$userip][OK]" . json_encode($data) . PHP_EOL);  
	fclose($fp);  
	
}

function write_cdr_query_log_and_die($data)	{
	global $today_full;
	global $userip;
	global $conn;
	$_logfile = 'cdr_audit.csv';
	$header = 'HTTP/1.0 500 Server Internal Error'; 
	$diemsg = "Unknow Error";

	// $audit = array($today_full, $userip, json_encode($data));
	if (isset($data['logmsg']))	{writelog($data['logmsg']); unset($data['logmsg']);}
	if (isset($data['header']))	{$header = $data['header']; unset($data['header']);}
	if (isset($data['diemsg']))	{$diemsg = $data['diemsg']; unset($data['diemsg']);}

	$fp = fopen($_logfile, 'a');	//opens file in append mode  
	// fputcsv($fp, $audit);
	fwrite($fp, "[$today_full][$userip][Failed]" . json_encode($data) . PHP_EOL);  
	fclose($fp);  

	if ($conn)	{
		$conn -> close();
	}

	header($header);
	die ($diemsg);
}

function read_last_cdr_query()	{
	$_logfile = 'cdr_audit.csv';

	$rows = file($_logfile);

	$last_row = array_pop($rows);

	// $data = str_getcsv($last_row);
	if (strlen($last_row) > 20)
		return substr($last_row, 1, 19);
	else 
		return '1970-01-01 00:00:00';
}


function webhook_cdr_register($data)	{
	writelog("Webhook CDR Registration: - " . json_encode($data));
	if (isset($data['url']) && filter_var($data['url'], FILTER_VALIDATE_URL))	{
		writelog("URL Registered: - " . $data['url']);
		write_php_ini(array("url" => $data['url']), "webhook_cdr.ini");
		die("URL Registered: - " . $data['url']);
	} else {
		writelog("Invalib URL: - " . $data['url']);
		die("Invalid URL");
	}
}


function webhook_missedcall_register($data)	{
	writelog("Webhook Missedcall Registration: - " . json_encode($data));
	if (isset($data['url']) && filter_var($data['url'], FILTER_VALIDATE_URL))	{
		writelog("URL Registered: - " . $data['url']);
		write_php_ini(array("url" => $data['url']), "webhook_missedcall.ini");
		die("URL Registered: - " . $data['url']);
	} else {
		writelog("Invalib URL: - " . $data['url']);
		die("Invalid URL");
	}
}


function write_php_ini($array, $file)
{
    $res = array();
    foreach($array as $key => $val)
    {
        if(is_array($val))
        {
            $res[] = "[$key]";
            foreach($val as $skey => $sval) $res[] = "$skey = ".(is_numeric($sval) ? $sval : '"'.$sval.'"');
        }
        else $res[] = "$key = ".(is_numeric($val) ? $val : '"'.$val.'"');
    }
    safefilerewrite($file, implode("\r\n", $res));
}

function safefilerewrite($fileName, $dataToSave)
{    if ($fp = fopen($fileName, 'w'))
    {
        $startTime = microtime(TRUE);
        do
        {            $canWrite = flock($fp, LOCK_EX);
           // If lock not obtained sleep for 0 - 100 milliseconds, to avoid collision and CPU load
           if(!$canWrite) usleep(round(rand(0, 100)*1000));
        } while ((!$canWrite)and((microtime(TRUE)-$startTime) < 5));

        //file was locked so now we can store information
        if ($canWrite)
        {            fwrite($fp, $dataToSave);
            flock($fp, LOCK_UN);
        }
        fclose($fp);
    }

}
?>