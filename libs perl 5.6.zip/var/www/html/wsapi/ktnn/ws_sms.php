<?php
date_default_timezone_set("Asia/Ho_Chi_Minh");

//	Authenticate Trustsales
{
$valid_passwords = array ("trustsales" => "waJ3ZfuM5QNSAAkNHUfskbOsHvi5w9Z3");
$valid_users = array_keys($valid_passwords);

$user = $_SERVER['PHP_AUTH_USER'];
$pass = $_SERVER['PHP_AUTH_PW'];

$validated = (in_array($user, $valid_users)) && ($pass == $valid_passwords[$user]);

if (!$validated) {
	writelog("Unauthorized request: $user / $pass ");
	header('WWW-Authenticate: Basic realm="ITY CallCenter API"');
	header('HTTP/1.0 401 Unauthorized');
	die ("Invalid Username or Password");
}
}

// Initiate parameters and values
{
	$today 		= date('Y-m-d');
	$today_full	= date('Y-m-d H:i:s');
	$yesterday 	= date('Y-m-d',strtotime("-1 days"));
	$lastmonth 	= date('Y-m-d',strtotime("-30 days"));

	$gw_default_username = 'admin';
	$gw_default_password = '#HTC@2016*';

$gwip = array (	 'gsm814'	=> '192.168.8.14'
				,'gsm914'	=> '192.168.9.14'
				,'gsm9119'	=> '192.168.9.119'
				,'gsm2016'	=> '192.168.9.116'
				,'gsm508'	=> '192.168.8.58'
				);

$gwports['gsm508'] = array(11,12,13);			// Mobifone

$userip = real_ip();

$mobileprefix = array ("090", "091", "093", "094", "096", "097", "098"
					, "081", "082", "083", "084", "085", "086", "088", "089"
					, "070", "071", "072", "073", "074", "075", "076", "077", "078", "079"
					, "030", "031", "032", "033", "034", "035", "036", "037", "038", "039"
					);

$vtlprefix = array("096", "097", "098", "086", "030", "031", "032", "033", "034", "035", "036", "037", "038", "039");
$vmsprefix = array("090", "093", "089", "070", "071", "072", "073", "074", "075", "076", "077", "078", "079");
$vnpprefix = array("091", "094", "081", "082", "083", "084", "085", "088");
}

// DB config and connect
{
$dbhost = "localhost";
$dbuser = "fusionpbx";
$dbpass = "aAHsz2RWlftbVmehvvxmRBSY";
$dbname = "fusionpbx";

$dbconnstring = "host=$dbhost port=5432 dbname=$dbname user=$dbuser password=$dbpass options='--client_encoding=UTF8'";

$conn = pg_connect($dbconnstring);
$dbstat = pg_connection_status($conn);
	if ($dbstat !== PGSQL_CONNECTION_OK || !$conn) {
		writelog("DB Connection Failed");
		header("HTTP/1.0 500 Internal Server Error");
		die("Err: DB error");
	}   
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
	if (isset($_REQUEST['action']))	{
		$data['action'] = trim(urldecode($_REQUEST['action']));
	} else {
		$data['action'] = "query_sms_inbox";
	}
	if (isset($_REQUEST['flag']))	{
		$data['flag'] = trim(urldecode($_REQUEST['flag']));
	} else {
		$data['flag'] = "unread";
	}

	$lastquerytime = read_last_sms_query();
	write_sms_query_log($data);
	if (time() - strtotime($lastquerytime) < 60)	{
		writelog("Too many query sms request from '$userip'");
		pg_close($conn);
		header('HTTP/1.0 400 Bad Request');
		die ("Too many request! Due to prevent the performance overload, this action is limited to 1 (one) request per minute. Please wait until " . date('Y-m-d h:i:s', strtotime($today_full) + 60) . ". Sorry for the inconvenience!");
	}

	// Get SMS Inbox
	$sql = "SELECT * FROM v_sms_inbox WHERE received_time > '$yesterday' AND apiread = 0 ORDER BY received_time";
	$result = pg_query($conn, $sql);
	$smslist = array();
	$smslistupdate = array();
	if (!$result) {
		writelog("DB error, failed to select sms inbox: '$sql'");
		pg_close($conn);
		header('HTTP/1.0 500 Internal Server Error');
		die ("Unable to get SMS! Please check your Administrator!");
	}
	if (pg_num_rows($result) > 0) {
		while ($row = pg_fetch_assoc($result)) {
			$sms = array();
			$sms['phone']	= $row['phone_number'];
			$sms['agent']	= $row['agent'];
			$sms['accountcode'] 	= $row['accountcode'];
			$sms['received_time']	= $row['received_time'];
			$sms['message']	= $row['message'];

			$smslist[] = $sms;

			if ($row['apiread'] == 0) $smslistupdate[] = $row['id'];
		}
	}
	if (count($smslistupdate) > 0)	{
		if (count($smslistupdate) > 1)	{
			$sql = "UPDATE v_sms_inbox SET apiread = 1, query_time = NOW() WHERE id IN (" . implode(",", $smslistupdate) . ")";
		} else {
			$sql = "UPDATE v_sms_inbox SET apiread = 1, query_time = NOW() WHERE id = $smslistupdate[0]";
		}
	}
	$result = pg_query($conn, $sql);
	if (!$result) {
		writelog("DB error, failed to update apiread for sms unread: '$sql'");
		pg_close($conn);
		header('HTTP/1.0 500 Internal Server Error');
		die ("Unable to update SMS status! Please check your Administrator!");
	}
	die(json_encode(array("sms" => $smslist, "unread" => count($smslist))));
}



// Get POST information
$data = json_decode(file_get_contents('php://input'), true);

	$post_actions 	= array("webhook_smsinbox_register");
	if (isset($data['action']) && in_array($data['action'], $post_actions))	{
		call_user_func_array($data['action'], array($data));
		die("Unknown Error");
	}



// AccountCode processing
{
	if (!isset($data['accountcode'])) 	{
		writelog("AccountCode must be specified " . json_encode($data));
		pg_close($conn);
		header('HTTP/1.0 400 Bad Request');
		die ("AccountCode must be specified!");
	}
	$accountcode = trim(preg_replace('~[^0-9a-z\\s]~i', '', $data['accountcode']));
	if ($accountcode !== $data['accountcode']  ||  strlen($accountcode) > 20)	{
		writelog("Invalid accountcode - " . json_encode($data));
		pg_close($conn);
		header('HTTP/1.0 400 Bad Request');
		die ("Invalid AccountCode '" . $data['accountcode'] . "', compare to " . $accountcode . "!");
	}

	// Get accountcode information
	$sql = "select * from v_accountcode where accountcode = '$accountcode' and enabled = 1";
	$result = pg_query($conn, $sql);
	if (!$result) {
		writelog("DB error, failed to select accountcode: '$accountcode' - " . json_encode($data));
		pg_close($conn);
		header('HTTP/1.0 500 Internal Server Error');
		die ("Unable to check AccountCode information! Please check your Administrator!");
	}
	if (pg_num_rows($result) > 0) {
		while ($row = pg_fetch_assoc($result)) {
			$account = $row;
		}
	} else {
		writelog("Accountcode does not exist - " . json_encode($data));
		pg_close($conn);
		header('HTTP/1.0 400 Bad Request');
		die ("AccountCode '" . $accountcode . "' does not exist!");
	}
}

// Extension processing
{
	if (!isset($data['extension'])) 	{
		writelog("Extension must be specified " . json_encode($data));
		pg_close($conn);
		header('HTTP/1.0 400 Bad Request');
		die ("Extension must be specified!");
	}
	$extension = preg_replace('/\D/', '', $data['extension']);
	if ($extension !== $data['extension']  ||  strlen($extension) > 6)	{
		writelog("Invalid extension - " . json_encode($data));
		pg_close($conn);
		header('HTTP/1.0 400 Bad Request');
		die ("Invalib Extension '" . $data['extension'] . "', compare to " . $extension . "!");
	}

	// Get extension information
	$sql = "select * from v_extensions where accountcode = '$accountcode' and extension = '$extension' and enabled = 'true'";
	$result = pg_query($conn, $sql);
	if (!$result) {
		writelog("DB error, failed to select extension: '$extension' - " . json_encode($data));
		pg_close($conn);
		header('HTTP/1.0 500 Internal Server Error');
		die ("Unable to check Extension information! Please check your Administrator!");
	}
	if (pg_num_rows($result) > 0) {
		while ($row = pg_fetch_assoc($result)) {
			$extinfo = $row;
		}
	} else {
		writelog("Extension does not exist - " . json_encode($data));
		pg_close($conn);
		header('HTTP/1.0 400 Bad Request');
		die ("Extension '" . $extension . "' does not exist!");
	}
}

// Phone processing
{
	if (!isset($data['phone'])) 	{
		writelog("Phone number must be specified " . json_encode($data));
		pg_close($conn);
		header('HTTP/1.0 400 Bad Request');
		die ("Phone number must be specified!");
	}
	$phone = preg_replace('/\D/', '', $data['phone']);
	if ($phone !== $data['phone']  ||  strlen($phone) != 10)	{
		writelog("Invalid phone number - " . json_encode($data));
		pg_close($conn);
		header('HTTP/1.0 400 Bad Request');
		die ("Invalid Phone number '" . $data['phone'] . "', compare to " . $phone . "!");
	}
	$phoneprefix = substr($phone, 0, 3);
	if (!in_array($phoneprefix, $mobileprefix))	{
		writelog("Invalid phone number, not in Viettel, Mobifone, Vinaphone - " . json_encode($data));
		pg_close($conn);
		header('HTTP/1.0 400 Bad Request');
		die ("Phone number '" . $data['phone'] . "' must be Viettel or Mobifone or Vinaphone!");
	}
}

// Message processing
{
	if (!isset($data['message'])) 	{
		writelog("Message must be specified " . json_encode($data));
		pg_close($conn);
		header('HTTP/1.0 400 Bad Request');
		die ("Message must be specified!");
	}
	$message = trim(preg_replace('~[^\P{Cc}\r\n]+~u', '', $data['message']));
	if (strlen($message) == 0)	{
		writelog("Invalid Message " . json_encode($data));
		pg_close($conn);
		header('HTTP/1.0 400 Bad Request');
		die ("Invalid Message!");
	}
	if (strlen($message) > 256)	{
		writelog("Message too long" . json_encode($data));
		pg_close($conn);
		header('HTTP/1.0 400 Bad Request');
		die ("Message too long!");
	}
}

writelog("[" . $extension . "] send SMS to [" . $phone . "] with message '" . $message . "'");

// Initiate Destination configuration
{
	$sms['sender']  	= $extension;
	$sms['message']		= $message;
	$sms['phone']		= $phone;
	$sms['accountcode']	= $accountcode;

	$sms['hash'] = hash('md5', $sms['sender'] . $sms['phone'] . $sms['message']);
	$sms['status'] = 0;
	$sms['statusdesc'] = 'NEW';

	$gw['name'] = 'gsm508';
	$gw['ip']   = '192.168.8.58';
	$gw['user'] = $gw_default_username;
	$gw['pass'] = $gw_default_password;

	if (in_array($phoneprefix, $vtlprefix))	{
		$gw['port'] = 11;
	} else if (in_array($phoneprefix, $vmsprefix))	{
		$gw['port'] = 13;
	} else if (in_array($phoneprefix, $vnpprefix))	{
		$gw['port'] = 13;
	} else {
		writelog("Undefined destination port - " . json_encode($data));
		pg_close($conn);
		header('HTTP/1.0 500 Internal Server Error');
		die ("Undefined Destination! Please check your Administrator!");
	}
}


	$sms['id'] = insert_sms_to_db($conn, $sms, $gw);
	if ( false===$sms['id'] ) {
		pg_close($conn);
		header('HTTP/1.0 500 Internal Server Error');
		die ("Unable to enqueue SMS message! Please check your Administrator!");
	}

	$sms = send_sms_to_gw($sms, $gw);

	if (isset($sms['result']['error_code']) && $sms['result']['error_code'] == 202)	{
		if (update_sms($conn, $sms))
			writelog("Update OK");
	}


	echo "Tin nhắn '" . $message . "' từ agent [" . $extension . "] đang được gửi tới " . $phone . "!";

pg_close($conn);




function send_sms_to_gw($sms, $gw)	{

	$content = build_sms_json($sms, $gw);

	$url = 'http://' . $gw['ip'] . '/api/send_sms';
	$ch = curl_init($url);
	// $jsonDataEncoded = json_encode($data);
	//Tell cURL that we want to send a POST request.
	curl_setopt($ch, CURLOPT_POST, 1);
	 
	//Attach our encoded JSON string to the POST fields.
	// curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonDataEncoded);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $content);
	 
	//Set the content type to application/json
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json')); 

	// curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_USERPWD, $gw['user'] . ":" . $gw['pass']);
	curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);

	//Execute the request
	$result = curl_exec($ch);
	// $info = curl_getinfo($ch);

	writelog('cURL sent: ' .  $url . ' - ' . $content . ' - ' . $result);

	$sms['result'] = json_decode($result, TRUE);

	return $sms;
}

function build_sms_json($sms, $gw)	{
	$dest[] = array(
				"number" => $sms['phone']
				// ,"text_param" => ""
				,"user_id" => $sms['id']
			);
	$content = array(
		 "text" 	=> $sms['message']
		,"port" 	=> array($gw['port'])
		,"encoding" => 'unicode'
		,"request_status_report" => 'true'
		,"param" 	=> $dest
	);
	return json_encode($content);
}

function insert_sms_to_db(&$conn, $sms, $gw)	{

	$sql = "SELECT hash FROM v_sms_outbox WHERE hash = '" . $sms['hash'] . "' AND processing_time > '" . date('Y-m-d H:i:s', strtotime('-4 hour')) . "' ORDER BY processing_time DESC LIMIT 1";
	// writelog($query);
	$result = pg_query($conn, $sql);
	if ($result  &&  pg_num_rows($result) > 0) {
		pg_close($conn);
		writelog($sms['phone'] . " - Duplicated SMS Entry in the last 1 hour!");
		header('HTTP/1.0 429 Too Many Requests');
		die ("Duplicated SMS Entry in the last 1 hour!");
	}

	$phone_number	= pg_escape_string($sms['phone']);
	$message 		= pg_escape_string($sms['message']);
	$accountcode 	= pg_escape_string($sms['accountcode']);
	$agent 			= pg_escape_string($sms['sender']);
	$gw_name 		= pg_escape_string($gw['name']);
	$gw_ip 			= pg_escape_string($gw['ip']);
	$gw_port 		= pg_escape_string($gw['port']);
	$hash 			= pg_escape_string($sms['hash']);
	$status 		= pg_escape_string($sms['status']);
	$statusdesc 	= pg_escape_string($sms['statusdesc']);
	$sql = "INSERT INTO v_sms_outbox
		(phone_number, 	  message, 	accountcode, 	agent, 	gw_name, 	gw_ip, 	gw_port, processing_time, 	sent_time, hash,   status,   statusdesc)
VALUES ('$phone_number','$message','$accountcode','$agent','$gw_name','$gw_ip','$gw_port',	NOW(),		NOW(),		 '$hash','$status','$statusdesc')
RETURNING id";

	$result = pg_query($conn, $sql);

	if (!$result) {
		writelog($sms['phone'] . " - DB Insert sms entry error! execute() failed: $sql - " . json_encode($sms));
		pg_close($conn);
		header('HTTP/1.0 500 Internal Server Error');
		die ("Unable to enqueue SMS message! Please check your Administrator!");
	} else if (pg_num_rows($result) > 0) {
		while ($row = pg_fetch_assoc($result)) {
			$id = $row['id'];
		}
		return $id;
	}
}

function update_sms(&$conn, $sms)	{
	
	if (!isset($sms['id']))	return false;

	$sql = "UPDATE v_sms_outbox SET";

	$construct = array();

	if (isset($sms['result']['error_code']))	$construct[] = " gw_send_code = " .  $sms['result']['error_code'];
	if (isset($sms['result']['sms_in_queue']))	$construct[] = " gw_in_queue = " .  $sms['result']['sms_in_queue'];
	if (isset($sms['result']['task_id']))		$construct[] = " gw_task_id = " .  $sms['result']['task_id'];

	if (empty($construct))	return false;

	$sql .= implode(", ", $construct);
	$sql .= " WHERE id = " . $sms['id'];

	writelog($sql);
	$result = pg_query($conn, $sql);

	if (!$result) {
		return false;
	}	else {
		return true;
	}
}

function writesmslog($sms, $strGatewayID)	{

	$_logfile = 'sms.log';

	$fp = fopen($_logfile, 'a');	//opens file in append mode  
	fwrite($fp, "[" . $sms['timestamp'] . "][" . $strGatewayID . "." . $sms["port"] . "][ID:" . $sms['incoming_sms_id'] . "][From:" . $sms['number'] . "]" . $sms['text'] . "\r\n" );  
	fclose($fp);  
	
}

function writelog($message)	{

	$_logfile = 'sms.log';

	$fp = fopen($_logfile, 'a');	//opens file in append mode  
	fwrite($fp, '[' . date('Y-m-d H:i:s') . '] ' . $message . PHP_EOL);  
	fclose($fp);  
	
}

function real_ip()	{
   $ip = $_SERVER['REMOTE_ADDR'];
    if (isset($_SERVER['HTTP_X_FORWARDED_FOR']) && preg_match_all('#\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}#s', $_SERVER['HTTP_X_FORWARDED_FOR'], $matches)) {
        foreach ($matches[0] AS $xip) {
            if (!preg_match('#^(10|172\.16|192\.168)\.#', $xip)) {
                $ip = $xip;
                break;
            }
        }
    } elseif (isset($_SERVER['HTTP_CLIENT_IP']) && preg_match('/^([0-9]{1,3}\.){3}[0-9]{1,3}$/', $_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (isset($_SERVER['HTTP_CF_CONNECTING_IP']) && preg_match('/^([0-9]{1,3}\.){3}[0-9]{1,3}$/', $_SERVER['HTTP_CF_CONNECTING_IP'])) {
        $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
    } elseif (isset($_SERVER['HTTP_X_REAL_IP']) && preg_match('/^([0-9]{1,3}\.){3}[0-9]{1,3}$/', $_SERVER['HTTP_X_REAL_IP'])) {
        $ip = $_SERVER['HTTP_X_REAL_IP'];
    }
    return $ip;

}

function sendsmsmail($sms)	{
	require("phpmailer/class.phpmailer.php"); // nạp thư viện gửi mail
	$mailer = new PHPMailer(); // khởi tạo đối tượng
	
	// Đăng nhập SMTP
	// Thiết lập SMTP Server
	$mailer->IsSMTP(); // gọi class smtp để đăng nhập

	// Thiết lập thông tin máy chủ mail
	$mailer->SMTPAuth 	= true; // gửi thông tin đăng nhập
	$mailer->SMTPSecure = "ssl";
	$mailer->Host       = "smtp.gmail.com";
	$mailer->Port       = 465;

	// Thông tin email client dùng để gửi
	$mailer->Username 	= 'ity.issabel.alert@gmail.com'; // tên đăng nhập
	$mailer->Password 	= "#ITY@2019*"; // mật khẩu
	$mailer->CharSet	="utf-8"; // bảng mã unicode

	// Chuẩn bị gửi thư nào
	$mailer->FromName 	= 'Issabel ITY SMS'; // tên người gửi
	$mailer->From 		= 'ity.issabel.alert@gmail.com'; // mail người gửi

	
	$mailer->AddAddress($sms['email'], '');
	// $mailer->AddBCC("nguyenthihaiyen1204@gmail.com", 'Yến Nguyễn Thị Hải');
	// $mailer->AddAddress("nv.khoa.bk@gmail.com", 'Khoa Nguyễn Việt');
	// $mailer->AddBCC("khoa.nguyen.viet.2012@gmail.com", 'Khoa Nguyễn Việt');

	$sub = "[ITY-SMS] SMS mới từ số điện thoại " . $sms['number'] . " vào lúc " . $sms['timestamp'];
	$mailer->Subject = $sub;							// tiêu đề
	$mailer->IsHTML(true); //Bật HTML không thích thì false


	// Nhúng ảnh để hiển thị trong email bằng CSS hay HTML
	// $mailer->AddEmbeddedImage('images/hinh.jpg', 'logoimg', 'hinh.jpg'); //đính kèm và nhúng ảnh vào email

	// Nội dung lá thư
	$mailbody 	= "<h3>Kính chào quý khách hàng " . $sms['accountcode']. "!</h3><br><br>";
	$mailbody  .= "Bạn có tin nhắn mới từ số điện thoại <b>" . $sms['number'] . "</b> vào lúc <b>" . $sms['timestamp'] . "</b> với nội dung:<br><br>";
	$mailbody  .= "<b>" . $sms['text'] . "</b><br><br>";
	$mailbody  .= "Agent có số máy lẻ <b>" . $sms['agent'] . "</b> là người gần nhất đã gọi đến khách hàng này vào lúc <b>" . $sms['lastcall'] . "</b><br><br>";
	$mailbody  .= "Mọi chi tiết xin liên hệ group Zalo Support.<br>Xin trân trọng cảm ơn!";
	
	$mailer->Body = $mailbody;							// nội dung
	// $mailer->Body = "<h1>Một lá thư gửi bằng PHPMailer</h1>
	// <p>Đây là hình ta mới nhúng lúc nảy: <img src=\"cid:logoimg\" /></p>";

	// Gửi email

	if(!$mailer->Send())	{
		// Gửi không được, đưa ra thông báo lỗi
		echo "Mailer error: " . $mailer->ErrorInfo . "\r\n";
	}	else 	{
		echo "Mailer sent successfully!\r\n";
	}
}

function write_sms_query_log($data)	{
	global $today_full;
	global $userip;
	$_logfile = 'sms_audit.csv';

	$audit = array($today_full, $userip, $data['action'], $data['flag']);

	$fp = fopen($_logfile, 'a');	//opens file in append mode  
	fputcsv($fp, $audit);
	fclose($fp);  
	
}

function read_last_sms_query()	{
	$_logfile = 'sms_audit.csv';

	$rows = file($_logfile);

	$last_row = array_pop($rows);

	$data = str_getcsv($last_row);

	if (isset($data[0]))
		return $data[0];
	else 
		return '1970-01-01 00:00:00';
}

function webhook_smsinbox_register($data)	{
	writelog("Webhook SMS Inbox Registration: - " . json_encode($data));
	if (isset($data['url']) && filter_var($data['url'], FILTER_VALIDATE_URL))	{
		writelog("URL Registered: - " . $data['url']);
		write_php_ini(array("url" => $data['url']), "webhook_smsinbox.ini");
		die("URL Registered: - " . $data['url']);
	} else {
		writelog("Invalib URL: - " . $data['url']);
		die("Invalid URL");
	}
}


function write_php_ini($array, $file)
{
    $res = array();
    foreach($array as $key => $val)
    {
        if(is_array($val))
        {
            $res[] = "[$key]";
            foreach($val as $skey => $sval) $res[] = "$skey = ".(is_numeric($sval) ? $sval : '"'.$sval.'"');
        }
        else $res[] = "$key = ".(is_numeric($val) ? $val : '"'.$val.'"');
    }
    safefilerewrite($file, implode("\r\n", $res));
}

function safefilerewrite($fileName, $dataToSave)
{    if ($fp = fopen($fileName, 'w'))
    {
        $startTime = microtime(TRUE);
        do
        {            $canWrite = flock($fp, LOCK_EX);
           // If lock not obtained sleep for 0 - 100 milliseconds, to avoid collision and CPU load
           if(!$canWrite) usleep(round(rand(0, 100)*1000));
        } while ((!$canWrite)and((microtime(TRUE)-$startTime) < 5));

        //file was locked so now we can store information
        if ($canWrite)
        {            fwrite($fp, $dataToSave);
            flock($fp, LOCK_UN);
        }
        fclose($fp);
    }

}
?>