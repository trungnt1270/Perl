<?php

// echo "test";
$err = false;
$err_header	= "";
$err_message= "";

$ipaddress = getenv("REMOTE_ADDR") ; 


/*
$iplist = array("118.70.109.34", "14.248.151.205", "192.168.8.192", "14.162.190.129", "58.187.161.171","103.252.1.210") ; 
// Echo "Your IP Address is " . $ipaddress; 
if (!filter_var($ipaddress, FILTER_VALIDATE_IP) || !in_array($ipaddress, $iplist)) {
	$err = true;
	$err_header = "HTTP/1.0 403 Forbidden";
    $err_message= json_encode(array("code" => 403, "message" => 'Err: IP Address is not Accepted: '));
}*/

if ($_SERVER['REQUEST_METHOD'] === 'GET') {

	$strPhone		= preg_replace('/[^0-9.]+/', '', urldecode($_REQUEST['phone']));
	$strExtension	= preg_replace('/[^0-9.]+/', '', urldecode($_REQUEST['extension']));
	$strSecret 		= trim(urldecode($_REQUEST['secret']));
} else {

	$data = json_decode(file_get_contents('php://input'), true);
	if (json_last_error() !== JSON_ERROR_NONE) {
		writelog("Bad request - Could not decode JSON");
		header('HTTP/1.0 400 Bad Request');
		die(json_encode(array("code" => 400, "message" => 'Could not decode JSON')));
	}
	if (empty($data))	{
		writelog("Bad request - No POST Data");
		header('HTTP/1.0 400 Bad Request');
		die(json_encode(array("code" => 400, "message" => "No data")));
	}

	$strPhone		= preg_replace('/[^0-9.]+/', '', $data['phone']);
	$strExtension	= preg_replace('/[^0-9.]+/', '', $data['extension']);
	$strSecret 		= trim($data['secret']);

	if (isset($data['callee_name']))	$callee_name = trim(preg_replace('~[^0-9a-z\\s]~i', '', $data['callee_name']));
	if (isset($data['callee_num']))		$callee_num = trim(preg_replace('~[^0-9x]~i', '', $data['callee_num']));
	// $strCompanyCode = trim($data['companycode']);
	// $strUserId 		= trim($data['userid']);
	// $strLayoutCode 	= trim($data['layoutcode']);
	// $strMasterId 	= trim($data['masterid']);
}

	if (isset($callee_num) && strcmp($callee_num, $data['callee_num']) !== 0) {
		$err = true;
		$err_header = "HTTP/1.0 400 Bad Request";
		$err_message= json_encode(array("code" => 400, "message" => 'Err: Invalid Callee number '));
	}
	if(empty($strPhone) || strlen($strPhone) < 3 || strlen($strPhone) > 10)	{
		$err = true;
		$err_header = "HTTP/1.0 400 Bad Request";
		$err_message= json_encode(array("code" => 400, "message" => 'Err: Wrong Phone Number'));
	}
	if(empty($strExtension) || strlen($strExtension) < 3 || strlen($strExtension) > 6)	{
		$err = true;
		$err_header = "HTTP/1.0 400 Bad Request";
		$err_message= json_encode(array("code" => 400, "message" => 'Err: Wrong Extension'));
	}
	if (strcmp($strSecret, "Ai27$3hsi7^h8Da8f") !== 0) {
		$err = true;
		$err_header = "HTTP/1.0 400 Bad Request";
		$err_message= json_encode(array("code" => 400, "message" => 'Err: Wrong Secret'));
	}


if ($err) {	
	header($err_header);
	echo($err_message);
} else {
	$strHost 	= "127.0.0.1";
	$strUser 	= "admin";
	$strSecret 	= "HTCcc@2017";
	$strChannel = "SIP/" . $strExtension;
	$strContext = "from-internal";
	//$strContext = "from-fail";
	$strWaitTime = "30000";
	$strPriority = "1";
	$strMaxRetry = "2";
	if (isset($callee_num))	{
		if (isset($callee_name))	
			$strCallerId = "$callee_name <$callee_num>";
		else
			$strCallerId = "$callee_num";
			
	} else 
		$strCallerId = "$strPhone";
	$oSocket = fsockopen ("127.0.0.1", 5038, $errno, $errstr, 20);
	if (!$oSocket) {
		header("HTTP/1.0 503 Service Unavailable");
		echo json_encode(array("code" => 503, "message" => "Err: Fail to Originate call"));
	} else {
		fputs($oSocket, "Action: login\r\n");
		fputs($oSocket, "Events: off\r\n");
		fputs($oSocket, "Username: $strUser\r\n");
		fputs($oSocket, "Secret: $strSecret\r\n\r\n");
		fputs($oSocket, "Action: originate\r\n");
		fputs($oSocket, "Channel: $strChannel\r\n");
		fputs($oSocket, "Exten: $strPhone\r\n");
		fputs($oSocket, "Context: $strContext\r\n");
		fputs($oSocket, "Priority: $strPriority\r\n");
		fputs($oSocket, "Timeout: $strWaitTime\r\n");
		fputs($oSocket, "CallerId: $strCallerId\r\n");
		// fputs($oSocket, "Account: MISA\r\n");
		// fputs($oSocket, "CallerID: $strPhone\r\n\r\n");
		fputs($oSocket, "Action: Logoff\r\n\r\n");
		sleep(2);
		fclose($oSocket);
		echo json_encode(array("code" => 200, "message" => "OK"));
	}
}
?>