<?php
	echo "OK";
writelog("Hangup url: " . 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF']);

function writelog($message)	{

	$_logfile = 'hangup.log';

	$fp = fopen($_logfile, 'a');	//opens file in append mode  
	fwrite($fp, '[' . date('Y-m-d H:i:s') . '] ' . $message . PHP_EOL);  
	fclose($fp);  
	
}

?>