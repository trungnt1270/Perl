<?php
date_default_timezone_set("Asia/Ho_Chi_Minh");
$today_full	= date('Y-m-d H:i:s');

$dbhost = "localhost";
$dbuser = "wsuser";
$dbpass = "myroot#";
$dbname = "asterisk";

$isMail = false;
$default_trunk_id = 2; // Proxy-8242
$default_trunk_proxy = "8242"; // Proxy-8242
$default_peer = array(	"allow" => "ulaw,alaw",
						"canreinvite" => "no",
						"context" => "from-proxy8242",
						"disallow" => "all",
						"dtmfmode" => "RFC2833",
						"host" => "192.168.8.242",
						"port" => "5062",
						"insecure" => "port,invite",
						"nat" => "no",
						"qualify" => "yes",
						"type" => "friend"
						);
$default_outboundroute_id = 2; // VNSALE_TO_ALL
$outboundroute_prepend = '810686';
$outboundroute_pattern = array(
								"ALL" => array(
											array("match_pattern_pass" => "0XXXXXXXXX", "match_callerid" => "", "prepend_digits" => $outboundroute_prepend)
										),
								"VTL" => array(
											array("match_pattern_pass" => "03XXXXXXXX", "match_callerid" => "", "prepend_digits" => $outboundroute_prepend),
											array("match_pattern_pass" => "086XXXXXXX", "match_callerid" => "", "prepend_digits" => $outboundroute_prepend),
											array("match_pattern_pass" => "09[6-8]XXXXXXX", "match_callerid" => "", "prepend_digits" => $outboundroute_prepend)
										),
								"VMS" => array(
											array("match_pattern_pass" => "07[06-9]XXXXXXX", "match_callerid" => "", "prepend_digits" => $outboundroute_prepend),
											array("match_pattern_pass" => "089XXXXXXX", "match_callerid" => "", "prepend_digits" => $outboundroute_prepend),
											array("match_pattern_pass" => "09[03]XXXXXXX", "match_callerid" => "", "prepend_digits" => $outboundroute_prepend)
										),
								"VNP" => array(
											array("match_pattern_pass" => "08[1-58]XXXXXXX", "match_callerid" => "", "prepend_digits" => $outboundroute_prepend),
											array("match_pattern_pass" => "09[14]XXXXXXX", "match_callerid" => "", "prepend_digits" => $outboundroute_prepend)
										),
								"OTHER" => array(
											array("match_pattern_pass" => "0[25]XXXXXXXX", "match_callerid" => "", "prepend_digits" => $outboundroute_prepend),
											array("match_pattern_pass" => "087XXXXXXX", "match_callerid" => "", "prepend_digits" => $outboundroute_prepend),
											array("match_pattern_pass" => "09[29]XXXXXXX", "match_callerid" => "", "prepend_digits" => $outboundroute_prepend)
										)
							);



/*
$iplist = array("118.70.109.34","54.86.50.139","101.99.6.55","171.229.161.29", "14.248.151.205", "194.233.66.235", "171.244.23.239", "14.232.244.63", "14.162.190.129", "27.79.233.16");
$userip = real_ip();
if (!filter_var($userip, FILTER_VALIDATE_IP) || !in_array($userip, $iplist)) {
	writelog("Err: IP Address is not Accepted: $userip");
	header("HTTP/1.0 403 Forbidden");
	die (json_encode(array('success' => false, 'error' => "IP Address is not Accepted: $userip")));
}*/

$partner = "Pancake";
$valid_passwords = array (
"pancake" => "Asi7ha7^h8Di2$38f"
,"C88100" => "ha7^h8Di2Asi738f"

);
$valid_users = array_keys($valid_passwords);

$user = $_SERVER['PHP_AUTH_USER'];
$pass = $_SERVER['PHP_AUTH_PW'];

$validated = (in_array($user, $valid_users)) && ($pass == $valid_passwords[$user]);

if (!$validated) {
	writelog("Unauthorized request: $user / $pass ");
	header('WWW-Authenticate: Basic realm="ITY CallCenter API"');
	header('HTTP/1.0 401 Unauthorized');
	die ("Invalid Username or Password");
}

// $actions = array("listext", "create_account", "add_extention", "delete_extension");
$actions = array(	"list_account", 
					"create_account", 
					"update_account", 
					"disable_account", 
					"enable_account", 
					"delete_account", 
					"list_extension", 
					"add_extention", 
					"edit_extention", 
					"disable_extension", 
					"enable_extension", 
					"delete_extension"
				);

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
	if (isset($_REQUEST['action']))
		$data['action'] = $_REQUEST['action'];
	else 
		$data['action'] = "list_extension";
		$data['accountcode'] = $_SERVER['PHP_AUTH_USER'];
		// print_r($data['accountcode']);
	// if (isset($_REQUEST['accountcode']))
		// $data['accountcode'] = trim(urldecode($_REQUEST['accountcode']));
} else {
	$data = validateJSONData();
}

$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);
// Check connection
if ($conn->connect_error) {
	writelog("DB Connection Failed - " . $conn->connect_error);
	header("HTTP/1.0 500 Internal Server Error");
	die (json_encode(array('success' => false, 'error' => "DB error")));
} 

call_user_func_array($data['action'], array($data, $conn));

$conn->close();



function list_account($data, $conn)	{
	// Limit API GET Listext to 5 request per 10 minutes


	$isShow = false;
	if (isset($_REQUEST['channel_info']))	{
		$channel_info = trim(preg_replace('~[^0-9a-z\\s]~i', '', $_REQUEST['channel_info']));
		if ($channel_info == $_REQUEST['channel_info'] && ($channel_info == 'yes' || $channel_info === '1' || $channel_info == 'true'))
			$isShow = true;
	}

	$sql = "select * from accountcode where partner = 'Pancake' order by id";
	$result = $conn->query($sql);
	if (!$result) {
		writelog("DB error, failed to retrieve accounts for 'VNSale' - " . json_encode($data));
		header('HTTP/1.0 500 Internal Server Error');
		die (json_encode(array('success' => false, 'error' => "Unable to retrieve account list information! Please check your Administrator!")));
	}


	$acclist = array();
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$account = array("accountcode" => $row['accountcode'], "total_agent" => $row['agentnumber'], "created" => $row['created'], "modified" => $row['modified'], "active" => $row['enabled']?"yes":"no");
			if ($isShow)	{
				if (isset($row['limit_viettel']))		$account['limit_viettel'] = $row['limit_viettel'];
				if (isset($row['limit_mobifone']))		$account['limit_mobifone'] = $row['limit_mobifone'];
				if (isset($row['limit_vinaphone']))		$account['limit_vinaphone'] = $row['limit_vinaphone'];
				if (isset($row['outnet']))				$account['outnet'] = $row['outnet']?"yes":"no";
				if (isset($row['overlimit_outnet']))	$account['overlimit_outnet'] = $row['overlimit_outnet']?"yes":"no";
			}
			$acclist[] = $account;
		}
		$result = array (
				"success" => true
				,"account_list" => $acclist
				// ,"uri" => "wss://tongdai145.siptrunk.vn:60145:58089/ws"
				);
	} else {
		$result = array ("success" => false,	"error" => "No account found!");
	}

	echo json_encode($result);
	writelog("Provided list account for VNSale | Request: " . json_encode($data) . " | Response: " . json_encode($result));

	if ($isMail && $result['success'])	{
		$mail = array (	'subject' => "VNSale lấy thông tin ext của khách hàng $accountcode "
						,'content'=> "VNSale đã lấy thông tin tài khoản của khách hàng $accountcode với " . $account['created'] . " extension, danh sách như sau:<br>"	);
		foreach ($acclist as $acc)	{
			$mail['content'] .= "Accountcode: " . $acc['accountcode'] . " 	- Total Agent: " . $acc['total_agent'] . "			- Active: " . $acc['active'] . " <br>";
		}
		sendalertmail($mail);
	}
}

function create_account($data, $conn)	{
	global $partner, $default_trunk_proxy, $default_peer;

/*	// Limit API Create request to 5 new AccountCode per 30 minutes
	$sql = "SELECT UNIX_TIMESTAMP(created) AS created_unix FROM accountcode WHERE created >  (NOW() - INTERVAL 30 MINUTE) order by created desc";
	// $sql = "SELECT UNIX_TIMESTAMP(created) AS created_unix FROM accountcode WHERE created >  (NOW() - INTERVAL 10 HOUR) order by created desc";
	$result = $conn->query($sql);
	if ($result->num_rows > 4) {
		while($row = $result->fetch_assoc()) 	$firstcreated = $row["created_unix"];
		$today_unix	= time();
		writelog("Too many Create Request! Only 5 new AccountCode can be created within 30 minutes! Please wait in " . ceil(($today_unix - $firstcreated)/60) . " minutes.");
		header('HTTP/1.0 603 Declined');
		die (json_encode(array('success' => false, 'error' => "Too many Create Request! Only 5 new AccountCode can be created within 30 minutes! Please wait in " . ceil(($today_unix - $firstcreated)/60) . " minutes.")));
	}
*/

	{	// check input values 
		$accountcode = checkAccountcode($data, $conn, false, true);

		if (isset($data['agentnumber']))		$agentnumber = preg_replace('/\D/', '', $data['agentnumber']) * 1;
		else $agentnumber = 0;

		if ($agentnumber > 30)	{
			writelog("Too many agent number - " . json_encode($data));
			header('HTTP/1.0 400 Bad Request');
			die (json_encode(array('success' => false, 'error' => "Agent number is limit to lower than 30 per request. Please create 30 agent, then add more later!")));
		}

		if (isset($data['agentlist']) && is_array($data['agentlist']) && count($data['agentlist']) > 0)	{
			foreach ($data['agentlist'] as $agent)	{
				$agentlist[] = substr(trim(preg_replace('~[^0-9a-z\\s]~i', '', $agent)), 0, 20);
			}
			$data['agentlist'] = $agentlist;
			if (count($agentlist) < $agentnumber) 	{
				writelog("Agent List counted lower than Agent Number, last agents will be created with different names");
			}
			if (count($agentlist) > $agentnumber) 	{
				writelog("Agent List counted more than Agent Number, last agent name will be ignored");
			}
		}

		// Get accountcode extension prefix
		$extprefix = '';
			$sql = "select extprefix + 1 as prefix from accountcode order by extprefix desc limit 1";
			$result = $conn->query($sql);

			if ($result->num_rows > 0) {
				while($row = $result->fetch_assoc()) {
					$extprefix = $row["prefix"];
				}
			} else {
				writelog("No preinstalled accountcode for create new one - " . json_encode($data));
				header('HTTP/1.0 500 Server Internal Error');
				die (json_encode(array('success' => false, 'error' => "Data Error. Unable to create new account. Please check your Administrator!")));
			}

		$active = 1;
		if (isset($data['active'])) {
			$active = substr(trim(preg_replace('~[^0-9a-z\\s]~i', '', $data['active'])), 0, 5);
			if ($active === '0' || $active == 'no') $active = 0;
			else $active = 1;
		}

		
		// Outboundrote
		$outbound_route = checkOutboundRoute($data);

	}

	{	// generate access_token
		$access_token = pbxapi_authenticate();
		// echo $access_token;
		if (empty($access_token))	{
			writelog("PBXAPI connection failed, please check httpd ssl error log - " . json_encode($data));
			header('HTTP/1.0 500 Server Internal Error');
			die (json_encode(array('success' => false, 'error' => "API connection error. Unable to create new account. Please check your Administrator!")));
		}
	}



	$trunkid_created = array();
	$outrtid_created = array();
	{	// if ($outbound_route['isLimit'])	{	// create outbound_route to limit call -> always create trunk & route
		$result_outbound_route = array();
		$trunk_info_name = $accountcode."-".$default_trunk_proxy."-";
		$trunk_info['peer'] = $default_peer;
		$trunk_info['reload'] = false;
		$backup_trunkid = null;

		try {
			// Create OutNet Trunk and Outbound Route
			$trunk_info['name'] = $trunk_info['channel_name'] = $trunk_info_name."OTHER";
			if ($outbound_route['outnet'] > 0)	{
				$trunk_info['maxchans'] = 30;  // limit outbound outnet to 30 by default
			} else {
				$trunk_info['maxchans'] = 0;
			}
			$trunkid_created[] = $outbound_route['trunkid_outnet'] = pbxapi_trunk_post($access_token, $trunk_info);
			$outrtid_created[] = $outbound_route['outrtid_outnet'] = addOutboundroute("OTHER", $outbound_route['trunkid_outnet'], $extprefix, $accountcode, $access_token, false);
			if ($outbound_route['outnet'] > 0 && $outbound_route['overlimit_outnet'] > 0)
				// $backup_trunkid = $outbound_route['trunkid_outnet'];
				$backup_trunkid = null;

			// Create Viettel Trunk and Outbound Route
			$trunk_info['name'] = $trunk_info['channel_name'] = $trunk_info_name."VTL";
			if ($outbound_route['limit_viettel'] > 0)	{
				$result_outbound_route['limit_viettel'] = $trunk_info['maxchans'] = $outbound_route['limit_viettel'];
				$backup_trunkid_put = $backup_trunkid;
			} else {
				$trunk_info['maxchans'] = 0;
				$backup_trunkid_put = null;
			}
			$trunkid_created[] = $outbound_route['trunkid_viettel'] = pbxapi_trunk_post($access_token, $trunk_info);
			$outrtid_created[] = $outbound_route['outrtid_viettel'] = addOutboundroute("VTL", $outbound_route['trunkid_viettel'], $extprefix, $accountcode, $access_token, false, $backup_trunkid_put);

			// Create Mobifone Trunk and Outbound Route
			$trunk_info['name'] = $trunk_info['channel_name'] = $trunk_info_name."VMS";
			if ($outbound_route['limit_mobifone'] > 0)	{
				$result_outbound_route['limit_mobifone'] = $trunk_info['maxchans'] = $outbound_route['limit_mobifone'];
				$backup_trunkid_put = $backup_trunkid;
			} else {
				$trunk_info['maxchans'] = 0;
				$backup_trunkid_put = null;
			}
			$trunkid_created[] = $outbound_route['trunkid_mobifone'] = pbxapi_trunk_post($access_token, $trunk_info);
			$outrtid_created[] = $outbound_route['outrtid_mobifone'] = addOutboundroute("VMS", $outbound_route['trunkid_mobifone'], $extprefix, $accountcode, $access_token, false, $backup_trunkid_put);

			// Create Vinaphone Trunk and Outbound Route
			$trunk_info['name'] = $trunk_info['channel_name'] = $trunk_info_name."VNP";
			if ($outbound_route['limit_vinaphone'] > 0)	{
				$result_outbound_route['limit_vinaphone'] = $trunk_info['maxchans'] = $outbound_route['limit_vinaphone'];
				$backup_trunkid_put = $backup_trunkid;
			} else {
				$trunk_info['maxchans'] = 0;
				$backup_trunkid_put = null;
			}
			$trunkid_created[] = $outbound_route['trunkid_vinaphone'] = pbxapi_trunk_post($access_token, $trunk_info);
			$outrtid_created[] = $outbound_route['outrtid_vinaphone'] = addOutboundroute("VNP", $outbound_route['trunkid_vinaphone'], $extprefix, $accountcode, $access_token, false, $backup_trunkid_put);

			// sort outnet to last result array
			if ($outbound_route['outnet'] > 0)	{
				$result_outbound_route['outnet'] = 'yes';
				if ($outbound_route['overlimit_outnet'] > 0)
					$result_outbound_route['overlimit_outnet'] = 'yes';
			}

			writelog("Trunk created: " . implode(",", $trunkid_created));
			writelog("Outboundrote created: " . implode(",", $outrtid_created));
		} catch (Exception $e)	{
			writelog("Error insert new account record while creating trunk and outbound route: " . $e->getMessage() . " - " . json_encode($data));
			if (count($trunkid_created) > 0)
				pbxapi_trunk_delete($access_token, implode(",", $trunkid_created), false);
			if (count($outrtid_created) > 0)
				pbxapi_outboundroute_delete($access_token, implode(",", $outrtid_created), false); 
			header('HTTP/1.0 500 Server Internal Error');
			die (json_encode(array('success' => false, 'error' => "API Error. Unable to create new account. Please check your Administrator!")));
		}

	}


	try {  // create new accountcode entry
		$sql = "INSERT INTO accountcode (accountcode, created, modified, agentnumber, extprefix, enabled, partner, limit_viettel, limit_mobifone, limit_vinaphone, outnet, overlimit_outnet, trunkid_viettel, trunkid_mobifone, trunkid_vinaphone, trunkid_outnet, outrtid_viettel, outrtid_mobifone, outrtid_vinaphone, outrtid_outnet) VALUES (?, NOW(), NOW(), ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		$stmt = $conn->prepare($sql);
		$stmt->bind_param("sisisiiiiiiiiiiiii", $accountcode, $agentnumber, $extprefix, $active, $partner
			,$outbound_route['limit_viettel'], $outbound_route['limit_mobifone'], $outbound_route['limit_vinaphone'], $outbound_route['outnet'], $outbound_route['overlimit_outnet']
			,$outbound_route['trunkid_viettel'], $outbound_route['trunkid_mobifone'], $outbound_route['trunkid_vinaphone'], $outbound_route['trunkid_outnet']
			,$outbound_route['outrtid_viettel'], $outbound_route['outrtid_mobifone'], $outbound_route['outrtid_vinaphone'], $outbound_route['outrtid_outnet']);
		$stmt->execute();
		$accountid = $stmt->insert_id;
		$stmt->close();
		// echo $sql . " - " . $accountcode . " - " . $agentnumber . " - " . $extprefix;
	} catch (Exception $e)	{
		$conn->query("DELETE FROM accountcode WHERE accountcode='$accountcode'");
			if (count($trunkid_created) > 0)
				pbxapi_trunk_delete($access_token, implode(",", $trunkid_created), false);
			if (count($outrtid_created) > 0)
				pbxapi_outboundroute_delete($access_token, implode(",", $outrtid_created), false); 
		writelog("Error insert new account record: " . $e->getMessage() . " - " . json_encode($data));
		header('HTTP/1.0 500 Server Internal Error');
		die (json_encode(array('success' => false, 'error' => "DB Error. Unable to create new account. Please check your Administrator!")));
	}


	if ($agentnumber > 0 && $active)	{	// create extension list

		try {
			$extlist = insert_extension_list($data, $conn, $access_token, $accountcode, $agentnumber, $extprefix, $agentlist);
		} catch (Exception $e)	{
			$conn->query("DELETE FROM accountcode WHERE accountcode = '$accountcode'");
			if (count($trunkid_created) > 0)
				pbxapi_trunk_delete($access_token, implode(",", $trunkid_created), false);
			if (count($outrtid_created) > 0)
				pbxapi_outboundroute_delete($access_token, implode(",", $outrtid_created), false);
			writelog("Error create extension when creating account: " . $e->getMessage() . " - " . json_encode($data));
			header('HTTP/1.0 500 Server Internal Error');
			die (json_encode(array('success' => false, 'error' => "Extension creating error. Unable to create new account. Please check your Administrator!")));
		}

	} else if ($outbound_route['isLimit'])	{
		// Apply trunk && outbound route
	}


	$result = array ("success" => true
				,"accountcode" => $accountcode
				,"hostname" => "vnsale.siptrunk.vn"		// => should change to realm
				,"extension_created" => 0
				// ,"uri" => "wss://tongdai145.siptrunk.vn:60145:58089/ws"
				);

	if (isset($extlist) && is_array($extlist))	{
		$result['extension_created'] 	= count($extlist);
		$result['extension_list'] 		= $extlist;
	}
	if (isset($result_outbound_route))
		$result['outbound_route'] = $result_outbound_route;

	echo json_encode($result);
	writelog("Customer Created! \nRequest: " . json_encode($data) . " \nResponse: " . json_encode($result));
}

function update_account($data, $conn)	{
	global $partner, $default_trunk_proxy, $default_peer;

	// Limit API Update to 1 request per 5 minutes

	{	// check input values 
		$account = checkAccountcode($data, $conn, true);
		$accountcode = $account['accountcode'];

		// Outboundrote
		$outbound_route = checkOutboundRoute($data);

	}

	{	// generate access_token
		$access_token = pbxapi_authenticate();
		// echo $access_token;
		if (empty($access_token))	{
			writelog("PBXAPI connection failed, please check httpd ssl error log - " . json_encode($data));
			header('HTTP/1.0 500 Server Internal Error');
			die (json_encode(array('success' => false, 'error' => "API connection error. Unable to create new account. Please check your Administrator!")));
		}
	}

	$trunkid_created = array();
	$outrtid_created = array();
	try {	// if ($outbound_route['isLimit'])	{	//modify limit
		$result_outbound_route = array();
		$trunk_info_name = $accountcode."-".$default_trunk_proxy."-";
		$trunk_info['peer'] = $default_peer;
		$trunk_info['reload'] = false;
		$backup_trunkid = null;
		$is_backup_lasttime = $account['overlimit_outnet'];
		$extprefix = $account['extprefix'];

		if ($outbound_route['outnet'] <> $account['outnet'] && $account['trunkid_outnet'] > 0)	{
			if ($outbound_route['outnet'] > 0)
				$conn->query("UPDATE trunks SET maxchans = 30 WHERE trunkid = " . $account['trunkid_outnet']);
			else 
				$conn->query("UPDATE trunks SET maxchans = 0 WHERE trunkid = " . $account['trunkid_outnet']);
		}

/*		if ($outbound_route['overlimit_outnet'] > 0 && $account['overlimit_outnet'] == 0)	{
			// Add backup trunk 
			if ($outbound_route['limit_viettel'] > 0)	{
			}
		} else if ($outbound_route['overlimit_outnet'] == 0 && $account['overlimit_outnet'] > 0)	{
			// Remove backup trunk 
		} else if ($outbound_route['overlimit_outnet'] > 0)	{
			$backup_trunkid = $account['trunkid_outnet'];
		}*/

		if ($outbound_route['limit_viettel'] <> $account['limit_viettel'] && $account['trunkid_outnet'] > 0)		{
			$conn->query("UPDATE trunks SET maxchans = " . $outbound_route['limit_viettel'] . " WHERE trunkid = " . $account['trunkid_viettel']);
		}

		if ($outbound_route['limit_mobifone'] <> $account['limit_mobifone'])		{
			$conn->query("UPDATE trunks SET maxchans = " . $outbound_route['limit_mobifone'] . " WHERE trunkid = " . $account['trunkid_mobifone']);
		}

		if ($outbound_route['limit_vinaphone'] <> $account['limit_vinaphone'])		{
			$conn->query("UPDATE trunks SET maxchans = " . $outbound_route['limit_vinaphone'] . " WHERE trunkid = " . $account['trunkid_vinaphone']);
		}

		$conn->query("UPDATE accountcode SET limit_viettel = " . $outbound_route['limit_viettel'] . ",
											limit_mobifone = " . $outbound_route['limit_mobifone'] . ", 
											limit_vinaphone = " . $outbound_route['limit_vinaphone'] . ", 
											outnet = " . $outbound_route['outnet'] . "
						WHERE accountcode = '$accountcode'");

	} catch(\PDOException $e) {
            $msg  = $e->getMessage();
            $code = $e->getCode();
            $errors[]=array('status'=>'false','detail'=>$msg, 'code'=>$code);
            header('HTTP/1.0 500 Server Internal Error');
			die (json_encode(array('success' => false, 'error' => "DB Error. Unable to update account. Please check your Administrator!")));
	}

	$post = array (	"name" => "Ko xoa"
					,"secret" => generateRandomString(32)
					,"callgroup" => 11
					,"pickupgroup" => 11
					,"device.accountcode" => "Admin"
					,"reload" => "true"
				);
	pbxapi_extension_put($access_token, "11111", $post);

	$result = array ("success" => true
				,"accountcode" => $accountcode
				,"hostname" => "vnsale.siptrunk.vn"		// => should change to realm
				// ,"outbound_route" => 0
				// ,"uri" => "wss://tongdai145.siptrunk.vn:60145:58089/ws"
				);
	echo json_encode($result);
	writelog("Customer Updated! \nRequest: " . json_encode($data) . " \nResponse: " . json_encode($result));

}

function delete_account($data, $conn)	{
	// limit API Delete to 5 minutes
	
	// check input values
	$account = checkAccountcode($data, $conn, true);

	$agentnumber = $account['agentnumber'];

	$trunkdel = array();
	if ($account['trunkid_viettel'] > 0)	$trunkdel[] = $account['trunkid_viettel'];
	if ($account['trunkid_mobifone'] > 0)	$trunkdel[] = $account['trunkid_mobifone'];
	if ($account['trunkid_vinaphone'] > 0)	$trunkdel[] = $account['trunkid_vinaphone'];
	if ($account['trunkid_outnet'] > 0)		$trunkdel[] = $account['trunkid_outnet'];

	$outrtdel = array();
	if ($account['outrtid_viettel'] > 0)	$outrtdel[] = $account['outrtid_viettel'];
	if ($account['outrtid_mobifone'] > 0)	$outrtdel[] = $account['outrtid_mobifone'];
	if ($account['outrtid_vinaphone'] > 0)	$outrtdel[] = $account['outrtid_vinaphone'];
	if ($account['outrtid_outnet'] > 0)		$outrtdel[] = $account['outrtid_outnet'];
	

	{	// generate access_token
		$access_token = pbxapi_authenticate();
		// echo $access_token;
		if (empty($access_token))	{
			writelog("PBXAPI connection failed, please check httpd ssl error log - " . json_encode($data));
			header('HTTP/1.0 500 Server Internal Error');
			die (json_encode(array('success' => false, 'error' => "API connection error. Unable to create new account. Please check your Administrator!")));
		}
	}

	try {
		if (count($trunkdel) > 0)
			pbxapi_trunk_delete($access_token, implode(",", $trunkdel), false);
		if (count($outrtdel) > 0)
			pbxapi_outboundroute_delete($access_token, implode(",", $outrtdel), false); 
		if (count($account['agentnumber'])	> 0)	{
			$extList = getExtensionList($data, $conn, $account['accountcode']);
			if (count($extList) > 0)	{
				pbxapi_extension_delete($access_token, implode(",", $extList));
			}
		}
		$conn->query("DELETE FROM accountcodesip WHERE accountcode='" . $account['accountcode'] . "'");
		$conn->query("DELETE FROM accountcode WHERE accountcode='" . $account['accountcode'] . "'");
	} catch (Exception $e)	{
		writelog("Error delete account record: " . $e->getMessage() . " - " . json_encode($data));
		header('HTTP/1.0 500 Server Internal Error');
		die (json_encode(array('success' => false, 'error' => "Error while delete account. Please check your Administrator!")));
	}

	writelog("Customer " . $account['accountcode'] . " deleted!");
	echo json_encode(array('success' => true, 'message' => "Deleted"));
}


function list_extension($data, $conn)	{
	// echo "Hello " . $data['accountcode'];

	// Limit API GET Listext to 5 request per 10 minutes


	// AccountCode processing
	$account = checkAccountcode($data, $conn, true);


	if (isset($account) && isset($account['agentnumber']) && $account['agentnumber'] > 0)	{
		$sql = "SELECT * FROM accountcodesip WHERE accountcode = '" . $account['accountcode'] . "' order by extension";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) {
			while($row = $result->fetch_assoc()) {
				$extlist[] = array("extension" => $row['extension'], "name" => $row['name'], "secret" => $row['secret'], "active" => $row['enabled']?"yes":"no");
			}
		}
	} else {
		$extlist = array();
	}

	$result = array (
				"accountcode" => $account['accountcode']
				,"active" => $account['enabled']?"yes":"no"
				// ,"created_time" => $account['created'] != null && strtotime($account['created']) > 1609459200 ? $account['created'] : 'unset'
				,"extension_number" => $account['agentnumber']
				// ,"uri" => "wss://tongdai145.siptrunk.vn:60145:58089/ws"
				,"extension_list"	=> $extlist
				);
	if ($account['created'] != null && strtotime($account['created']) > 1609459200)
		$result["created_time"] = $account['created'];
	if ($account['modified'] != null && strtotime($account['modified']) > 1609459200)
		$result["modified_time"] = $account['modified'];

	echo json_encode($result);
	writelog("Brief Extension List: \nRequest: " . json_encode($data) . " \nResponse: " . json_encode($result));
}

function insert_extension_list($data, $conn, $access_token, $accountcode, $agentnumber, $extprefix, $agentlist, $isApplyChange = true, $first_ext = 1) {
	if ($agentnumber * 1 <= 0 || $extprefix * 1 <= 2000 || $extprefix * 1 > 3000)	{
		throw new \Exception('You gotta be kidding');
	}

	$stmt = $conn -> prepare("INSERT INTO accountcodesip (accountcode, extension, name, secret, enabled, created, modified) VALUES ('$accountcode', ?, ?, ?, 1, NOW(), NOW())");

	$extgroup 	= $extprefix;
	$extlist = array();
	$extcreated = array();
	// $maxretry = 3;
	$curlerr = "";
	for ($i = 0; $i < $agentnumber; $i++)	{
		$extension 	= $extprefix . sprintf("%03d", $i + $first_ext);

		if (isset($agentlist[$i]) && strlen($agentlist[$i]) > 3)
			$extname 	= $agentlist[$i];
		else 
			$extname 	= $accountcode . sprintf("%03d", $i + 1);

		$ext = array("extension" => $extension, "name" => $extname);
		$secret = generateRandomString(32);

		$post = array (	"name" => $extname
						,"secret" => $secret
						,"endpoint_type" => "webrtc"
						,"accountcode" => $accountcode
						,"callgroup" => $extgroup
						,"pickupgroup"=> $extgroup
				);

		if (!$isApplyChange)	
			$post["reload"] = "false";
		else if ($i < $agentnumber - 1)	{
			$post["reload"] = "false";
		}

		$result = pbxapi_extension_put($access_token, $extension, $post);
		if ($result &&
			$stmt -> bind_param('sss', $extension, $extname, $secret) &&
			$stmt -> execute()
		) {
			$ext["secret"] = $secret;
			$extcreated[] = $extension;
			$extlist[] = $ext;
		}/*
		else {
			writelog("Extension insert DB failed: " . htmlspecialchars($stmt->error));
			if (count($extcreated) > 0)	{
				pbxapi_extension_delete($access_token, implode(",", $extcreated));
				$conn->query("DELETE FROM accountcodesip WHERE extension IN ('" . implode("', '", $extcreated) . "')");
			}
			throw new \Exception('Error creating extension');
		}*/
	}

	return $extlist;
}

function add_extention($data, $conn)	{

	// Limit API Add extension to 5 request per 30 minutes

	{	// check input values 
		// $account = checkAccountcode($data, $conn, true);

		$agentnumber = 0;
		if (isset($data['agentnumber']))		$agentnumber = preg_replace('/\D/', '', $data['agentnumber']) * 1;
		if ($agentnumber <= 0) {
			writelog("Add Extension with no quantity value - " . json_encode($data));
			header('HTTP/1.0 400 Bad Request');
			die (json_encode(array('success' => false, 'error' => "Please specify how many agent you want to add")));
		}

		if ($agentnumber > 30)	{
			writelog("Too many agent number - " . json_encode($data));
			header('HTTP/1.0 400 Bad Request');
			die (json_encode(array('success' => false, 'error' => "Agent number is limit to lower than 30 per request. Please create 30 agent, then add more later!")));
		}

		if (isset($data['agentlist']) && is_array($data['agentlist']) && count($data['agentlist']) > 0)	{
			foreach ($data['agentlist'] as $agent)	{
				$agentlist[] = substr(trim(preg_replace('~[^0-9a-z\\s]~i', '', $agent)), 0, 20);
			}
			$data['agentlist'] = $agentlist;
			if (count($agentlist) < $agentnumber) 	{
				writelog("Agent List counted lower than Agent Number, last agents will be created with different names");
			}
			if (count($agentlist) > $agentnumber) 	{
				writelog("Agent List counted more than Agent Number, last agent name will be ignored");
			}
		}

	}


	{// Get accountcode extension prefix and last extension
		$extprefix = $account['extprefix'];
		$sql = "select extension from accountcodesip where accountcode = '" . $account['accountcode'] . "' order by extension desc limit 1";
		$result = $conn->query($sql);

		if ($result->num_rows > 0) {
			while($row = $result->fetch_assoc()) {
				$lastext = $row["extension"] % 1000 * 1;
			}
		} else 
			$lastext = 0;
	}

	{	// generate access_token
		$access_token = pbxapi_authenticate();
		// echo $access_token;
		if (empty($access_token))	{
			writelog("PBXAPI connection failed, please check httpd ssl error log - " . json_encode($data));
			header('HTTP/1.0 500 Server Internal Error');
			die (json_encode(array('success' => false, 'error' => "API connection error. Unable to create new account. Please check your Administrator!")));
		}
	}


	try {
		$extlist = insert_extension_list($data, $conn, $access_token, $account['accountcode'], $agentnumber, $extprefix, $agentlist, true, $lastext + 1);
	} catch (Exception $e)	{
		$conn->query("DELETE FROM accountcode WHERE accountcode = '$accountcode'");
		if (count($trunkid_created) > 0)
			pbxapi_trunk_delete($access_token, implode(",", $trunkid_created), false);
		if (count($outrtid_created) > 0)
			pbxapi_outboundroute_delete($access_token, implode(",", $outrtid_created), false);
		writelog("Error create extension when creating account: " . $e->getMessage() . " - " . json_encode($data));
		header('HTTP/1.0 500 Server Internal Error');
		die (json_encode(array('success' => false, 'error' => "Extension creating error. Unable to create new account. Please check your Administrator!")));
	}



	$sql = "UPDATE accountcode SET agentnumber = agentnumber + $agentnumber WHERE accountcode = '" . $account['accountcode'] . "'";
	if ($conn->query($sql) === TRUE) {
		writelog("Agentnumber of $accountcode updated successfully");
	} else {
		writelog("Agentnumber of $accountcode updated Error: " . $conn->error);
		foreach($extlist as $ext)
			$extcreated[] = $ext["extension"];
		pbxapi_extension_delete($access_token, implode(",", $extcreated));
		header('HTTP/1.0 500 Server Internal Error');
		die (json_encode(array('success' => false, 'error' => "Extension creating error. Unable to add extension to account. Please check your Administrator!")));
	}

	$result = array (
				"accountcode" => $account['accountcode']
				,"extension_added" => $agentnumber
				,"total_extension" => $agentnumber + $account['agentnumber']
				// ,"uri" => "wss://tongdai145.siptrunk.vn:60145:58089/ws"
				,"extension_list"	=> $extlist
				);
	echo json_encode($result);
	writelog("Extension Added! \nRequest: " . json_encode($data) . " \nResponse: " . json_encode($result));
}


function delete_extension($data, $conn)	{

	// Limit API Add extension to 5 request per 30 minutes

	// AccountCode processing
	if (!isset($data['accountcode'])) 	{
		writelog("AccountCode must be specified " . json_encode($data));
		header('HTTP/1.0 400 Bad Request');
		die ("AccountCode must be specified!");
	}

	$accountcode = trim(preg_replace('~[^0-9a-z\\s]~i', '', $data['accountcode']));

	if ($accountcode !== $data['accountcode'])	{
		writelog("Invalid accountcode - " . json_encode($data));
		header('HTTP/1.0 400 Bad Request');
		die ("AccountCode '" . $data['accountcode'] . "' contains invalid character(s), compare to " . $accountcode . "!");
	}
	if (strlen($accountcode) > 30)	{
		writelog("Accountcode too long - " . json_encode($data));
		header('HTTP/1.0 400 Bad Request');
		die ("AccountCode '" . $data['accountcode'] . "' length is longer than 30 characters!");
	}

	$sql = "select * from accountcode where accountcode = '$accountcode'";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		if ($result->num_rows > 1) {
			writelog("DB error, duplicated accountcode detected: '$accountcode' - " . json_encode($data));
			header('HTTP/1.0 500 Internal Server Error');
			die ("AccountCode duplicated! Please check your Administrator!");
		} 

		while($row = $result->fetch_assoc()) {
			$account = $row;
		}
	} else {
		writelog("Accountcode does not exist - " . json_encode($data));
		header('HTTP/1.0 400 Bad Request');
		die ("AccountCode '" . $accountcode . "' does not exist!");
	}

	if (isset($data['agentnumber']))		$agentnumber = preg_replace('/\D/', '', $data['agentnumber']) * 1;
	else $agentnumber = 0;

	if (!isset($data['extension_list']) || !is_array($data['extension_list']) || count($data['extension_list']) == 0)	{
		writelog("Unspecified Extension List to be Deleted - " . json_encode($data));
		header('HTTP/1.0 400 Bad Request');
		die ("Unspecified Extension List to be Deleted!");
	}

		foreach ($data['extension_list'] as $extension)	{
			$extension = preg_replace('/\D/', '', $extension) * 1;
			if (!is_null($extension) && strlen($extension) > 3)
				$extensionlist[] = $extension;
		}

	$sql = "SELECT extension FROM accountcodesip WHERE accountcode = '$accountcode' AND extension IN ('" . implode("','", $extensionlist) . "')";
	$result = $conn->query($sql);

	$extdelnum = 0;
	$extdellist = array();
	if ($result->num_rows > 0) {
		$access_token = pbxapi_authenticate();
		// echo $access_token;
		if (empty($access_token))	{
			writelog("PBXAPI connection failed, please check httpd ssl error log");
			header("HTTP/1.0 500 Internal Server Error");
			die("Err: PBXAPI error");
		}

		while($row = $result->fetch_assoc()) {
			$extension = $row['extension'];

			if (pbxapi_extension_delete($access_token, $extension)) {
				$extdellist[] = $extension;
				$extdelnum++;
			}
		}

		$result = $extdelnum . ' extension(s) have been deleted!';
	} else {
		$result = 'Extension(s) provided not found!';
	}

	$result = array (
			"action" => "delete_extension"
			,"result" => $result
			,"extension_deleted" => $extdellist
			);

	echo json_encode($result);
	writelog("Extension Deleted! \nRequest: " . json_encode($data) . " \nResponse: " . json_encode($result));
}



function validateJSONData()	{
	global $actions;
	$data = json_decode(file_get_contents('php://input'), true);
	if (json_last_error() !== JSON_ERROR_NONE) {
		writelog("Bad request - Could not decode JSON");
		header('HTTP/1.0 400 Bad Request');
		die (json_encode(array('success' => false, 'error' => "Could not decode JSON")));
	}
	if (empty($data))	{
		writelog("Bad request - No POST Data");
		header('HTTP/1.0 400 Bad Request');
		die (json_encode(array('success' => false, 'error' => "No data")));
	}
	if (!isset($data['action']) || !in_array($data['action'], $actions))	{
		writelog("Bad request - Missing action in request: " . json_encode($data));
		header('HTTP/1.0 400 Bad Request');
		die (json_encode(array('success' => false, 'error' => "Missing action in request")));
	}
	return $data;
}

function checkAccountcode($data, $conn, $isStrict = false, $checkCreate = false)	{
	if (!isset($data['accountcode'])) 	{
		writelog("AccountCode must be specified " . json_encode($data));
		if ($isStrict || $checkCreate)	{
			header('HTTP/1.0 400 Bad Request');
			die (json_encode(array('success' => false, 'error' => "AccountCode must be specified!")));
		}
		return false;
	}

	$accountcode = trim(preg_replace('~[^0-9a-z\\s]~i', '', $data['accountcode']));
	$accountcode = str_replace(" ", "", $accountcode);

	if ($accountcode !== $data['accountcode'])	{
		writelog("Invalid accountcode - " . json_encode($data));
		if ($isStrict || $checkCreate)	{
			header('HTTP/1.0 400 Bad Request');
			die (json_encode(array('success' => false, 'error' => "AccountCode '" . $data['accountcode'] . "' contains invalid character(s), compare to " . $accountcode . "!")));
		}
		return false;
	}
	if (strlen($accountcode) < 3)	{
		writelog("Accountcode too short - " . json_encode($data));
		if ($isStrict || $checkCreate)	{
			header('HTTP/1.0 400 Bad Request');
			die (json_encode(array('success' => false, 'error' => "AccountCode '" . $data['accountcode'] . "' too short!")));
		}
		return false;
	}
	if (strlen($accountcode) > 32)	{
		writelog("Accountcode too long - " . json_encode($data));
		if ($isStrict || $checkCreate)	{
			header('HTTP/1.0 400 Bad Request');
			die (json_encode(array('success' => false, 'error' => "AccountCode '" . $data['accountcode'] . "' length is longer than 32 characters!")));
		}
		return false;
	}

	$sql = "select * from accountcode where accountcode = '$accountcode'";
	$result = $conn->query($sql);
	if (!$result) {
		writelog("DB error, failed to select accountcode: '$accountcode' - " . json_encode($data));
		if ($isStrict || $checkCreate)	{
			header('HTTP/1.0 500 Internal Server Error');
			die (json_encode(array('success' => false, 'error' => "Unable to check AccountCode information! Please check your Administrator!")));
		}
		return false;
	}

	if ($result->num_rows > 0) {
		if ($checkCreate) 	{
			writelog("Accountcode exist - " . json_encode($data));
			header('HTTP/1.0 400 Bad Request');
			die (json_encode(array('success' => false, 'error' => "AccountCode '$accountcode' exist!")));
		}

		if ($result->num_rows > 1) {
			writelog("DB error, duplicated accountcode detected: '$accountcode' - " . json_encode($data));
			if ($isStrict || $checkCreate)	{
				header('HTTP/1.0 500 Internal Server Error');
				die (json_encode(array('success' => false, 'error' => "AccountCode duplicated! Please check your Administrator!")));
			}
			return false;
		} 

		while($row = $result->fetch_assoc()) {
			$account = $row;
		}
		return $account;
	} else {
		if ($checkCreate)	{
			return $accountcode;
		}
		writelog("Accountcode does not exist - " . json_encode($data));
		if ($isStrict)	{
			header('HTTP/1.0 400 Bad Request');
			die (json_encode(array('success' => false, 'error' => "AccountCode '$accountcode' does not exist!")));
		}
		return false;
	}
}

function checkOutboundRoute($data, $presetValue = true)	{
// function checkOutboundRoute($data)	{
	if ($presetValue)	{
		$outbound_route = array("limit_viettel"		=> 0,
							"limit_mobifone"	=> 0,
							"limit_vinaphone"	=> 0,
							"outnet"			=> 0,
							"trunkid_viettel"	=> 0,
							"trunkid_mobifone"	=> 0,
							"trunkid_vinaphone"	=> 0,
							"trunkid_outnet"	=> 0,
							"outrtid_viettel"	=> 0,
							"outrtid_mobifone"	=> 0,
							"outrtid_vinaphone"	=> 0,
							"outrtid_outnet"	=> 0,
							"overlimit_outnet"	=> 0,
							"isLimit"			=> false
							);
	} else {
		$outbound_route = array("isLimit"		=> false);
	}

	if (isset($data['outbound_route']) && is_array($data['outbound_route']))	{
		$route = $data['outbound_route'];

		if (isset($route['limit_viettel']))	{
			$limit_viettel = preg_replace('/[^\d-]+/', '', $route['limit_viettel']) * 1;
			if ($limit_viettel >= 0)	{
				$outbound_route['limit_viettel'] = $limit_viettel;
				$outbound_route['isLimit'] = true;
			}
		}

		if (isset($route['limit_mobifone']))	{
			$limit_mobifone = preg_replace('/[^\d-]+/', '', $route['limit_mobifone']) * 1;
			if ($limit_mobifone >= 0)	{
				$outbound_route['limit_mobifone'] = $limit_mobifone;
				$outbound_route['isLimit'] = true;
			}
		}

		if (isset($route['limit_vinaphone']))	{
			$limit_vinaphone = preg_replace('/[^\d-]+/', '', $route['limit_vinaphone']) * 1;
			if ($limit_vinaphone >= 0)	{
				$outbound_route['limit_vinaphone'] = $limit_vinaphone;
				$outbound_route['isLimit'] = true;
			}
		}

		if (isset($route['outnet']))	{
			$outnet = substr(trim(preg_replace('~[^0-9a-z\\s]~i', '', $route['outnet'])), 0, 5);
			if ($outnet == 'yes' || $outnet === '1' || $outnet == 'true')	{
				$outbound_route['outnet'] = 1;
				$outbound_route['isLimit'] = true;
			}
		}

		if (isset($route['overlimit_outnet']))	{
			$overlimit_outnet = substr(trim(preg_replace('~[^0-9a-z\\s]~i', '', $route['overlimit_outnet'])), 0, 5);
			if ($overlimit_outnet == 'yes' || $overlimit_outnet === '1' || $overlimit_outnet == 'true')
				$outbound_route['overlimit_outnet'] = 1;
		}

	}

	return $outbound_route;

}

function addOutboundroute($telco, $trunkid, $extprefix, $accountcode, $access_token, $isApplyChange = true, $backup_trunkid = null)	{
	global $outboundroute_pattern;

	$patterns = $outboundroute_pattern[$telco];

	$pattern_tmp = array();
	foreach ($patterns as $pattern)	{
		$pattern['match_callerid'] = $extprefix."XXX";
		$pattern_tmp[] = $pattern;
	}

	$route_info['name'] = $accountcode."_TO_".$telco;
	$route_info['patterns'] = $pattern_tmp;
	$route_info['trunks'] = array(array("trunk_id" => $trunkid, "sequence" => "0"));
	if (isset($backup_trunkid))	// backup trunk qua ngoai mang
		$route_info['trunks'][] = array("trunk_id" => $backup_trunkid, "sequence" => "1");

	if (!$isApplyChange)
		$route_info['reload'] = false;

	return pbxapi_outboundroute_post($access_token, $route_info);
}

function getExtensionList($data, $conn, $accountcode)	{
	$extlist = array();

	if (isset($accountcode))	{
		$sql = "SELECT * FROM accountcodesip WHERE accountcode = '" . $accountcode . "' order by extension";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) {
			while($row = $result->fetch_assoc()) {
				$extlist[] = $row['extension'];
			}
		}
	}

	return $extlist;
}

function writelog($message)	{
	global $today_full;
	global $userip;

	$_logfile = 'customer.log';

	$fp = fopen($_logfile, 'a');	//opens file in append mode  
	fwrite($fp, "[" . $today_full . "][" . $userip . "] " . $message . PHP_EOL);  
	fclose($fp);  
	
}

function cv2urltitle($text) {

	$text = str_replace(
	array('%',"/","\\",'"','?','<','>',"#","^","`","'","=","!",":" ,",,","..","*","&","__","?"),
	array('' ,'' ,''  ,'' ,'' ,'' ,'' ,'' ,'' ,'' ,'' ,'-','' ,'-' ,''  ,''  ,'' ,"_",""  ,""),
	$text);

	$chars = array("a","A","e","E","o","O","u","U","i","I","d", "D","y","Y");

	$uni[0] = array("á","à","a.","a?","a~","â","a^'","a^`", "a^.","a^?","a^~","?","a('","a(`","a(.","a(?","? ?");
	$uni[1] = array("Á","À","A.","A?","A~","Â","A^'","A^`", "A^.","A^?","A^~","?","A('","A(`","A(.","A(?","? ?");
	$uni[2] = array("é","è","e.","e?","e~","ê","e^'","e^`" ,"e^.","e^?","e^~");
	$uni[3] = array("É","È","E.","E?","E~","Ê","E^'","E^`" ,"E^.","E^?","E^~");
	$uni[4] = array("ó","o`","o.","o?","o~","ô","o^'","o^`", "o^.","o^?","o^~","?","o+'","o+`","o+.","o+?","? ?");
	$uni[5] = array("Ó","O`","O.","O?","O~","Ô","O^'","O^`", "O^.","O^?","O^~","?","O+'","O+`","O+.","O+?","? ?");
	$uni[6] = array("ú","ù","u.","u?","u~","?","u+'","u+`", "u+.","u+?","u+~","ù","ú","ủ","ũ","ụ");
	$uni[7] = array("Ú","Ù","U.","U?","U~","?","U+'","U+`", "U+.","U+?","U+~","Ù","Ú","Ủ","Ũ","Ụ");
	$uni[8] = array("í","i`","i.","i?","i~","ì","í","ỉ","ĩ","ị");
	$uni[9] = array("Í","I`","I.","I?","I~","Ì","Í","Ỉ","Ĩ","Ị");
	$uni[10] = array("?");
	$uni[11] = array("?");
	$uni[12] = array("y'","y`","y.","y?","y~","ỳ","ý","ỷ","ỹ","ỵ");
	$uni[13] = array("Y'","Y`","Y.","Y?","Y~","Ỳ","Ý","Ỷ","Ỹ","Ỵ");

	for($i=0; $i<=13; $i++) {
		$text = str_replace($uni[$i],$chars[$i],$text);
	}

	return $text;
}

function real_ip()	{
   $ip = $_SERVER['REMOTE_ADDR'];
    if (isset($_SERVER['HTTP_X_FORWARDED_FOR']) && preg_match_all('#\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}#s', $_SERVER['HTTP_X_FORWARDED_FOR'], $matches)) {
        foreach ($matches[0] AS $xip) {
            if (!preg_match('#^(10|172\.16|192\.168)\.#', $xip)) {
                $ip = $xip;
                break;
            }
        }
    } elseif (isset($_SERVER['HTTP_CLIENT_IP']) && preg_match('/^([0-9]{1,3}\.){3}[0-9]{1,3}$/', $_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (isset($_SERVER['HTTP_CF_CONNECTING_IP']) && preg_match('/^([0-9]{1,3}\.){3}[0-9]{1,3}$/', $_SERVER['HTTP_CF_CONNECTING_IP'])) {
        $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
    } elseif (isset($_SERVER['HTTP_X_REAL_IP']) && preg_match('/^([0-9]{1,3}\.){3}[0-9]{1,3}$/', $_SERVER['HTTP_X_REAL_IP'])) {
        $ip = $_SERVER['HTTP_X_REAL_IP'];
    }
    return $ip;

}

function pbxapi_authenticate()	{
	global $curlerr;
		$url = 'https://192.168.8.126/pbxapi/authenticate';
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, "user=admin&password=HTCcc@2017");
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$result = json_decode(curl_exec($ch), true);
		$curlerr = "Authenticate error: " . json_encode($result) . " - " . curl_error($ch);
		curl_close($ch);

		if (isset($result['access_token']))	
			return $result['access_token'];
		else {
			writelog($curlerr);
			return false;
		}
}

function pbxapi_extension_put($access_token, $extension, $post)	{
	global $curlerr;

		$url = 'https://192.168.8.218/pbxapi/extensions/' . $extension;
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post));
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json', 'Authorization: Bearer ' . $access_token)); 
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
		$result = json_decode(curl_exec($ch), true);
		$statusCode = curl_getInfo($ch, CURLINFO_HTTP_CODE);
		// $curlerr = "PUT extension $extension error: " . $statusCode . " - " . json_encode($post) . " - " . json_encode($result) . " - " . curl_error($ch) . " - Token: " . $access_token;
		$curlerr = "PUT extension $extension error: " . $statusCode . " - " . json_encode($post) . " - " . json_encode($result) . " - " . curl_error($ch);
		curl_close($ch);

		// if ($statusCode == 201 && isset($result['secret']))
		if ($statusCode == 201)
			// return $result['secret'];
			return true;
		else {
			writelog($curlerr);
			return false;
		}
}

function pbxapi_extension_delete($access_token, $extension)	{
	global $curlerr;

		$url = 'https://192.168.8.218/pbxapi/extensions/' . $extension;
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Authorization: Bearer ' . $access_token)); 
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
		$result = curl_exec($ch);
		$statusCode = curl_getInfo($ch, CURLINFO_HTTP_CODE);
		$curlerr = "DELETE extension $extension error: $url - " . $statusCode . " - " . json_encode($result) . " - " . curl_error($ch);
		curl_close($ch);

		if ($result === false || $statusCode != 200)	{
			writelog($curlerr);
			return false;
		} 	else 
			return true;
}

function pbxapi_trunk_post($access_token, $post)	{
	global $curlerr;

		$url = 'https://192.168.8.218/pbxapi/trunks';
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post));
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json', 'Authorization: Bearer ' . $access_token)); 
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
		curl_setopt($ch, CURLOPT_HEADERFUNCTION,
			function ($curl, $header) use (&$headers) {
				$len = strlen($header);
				$header = explode(':', $header, 2);
				if (count($header) < 2) // ignore invalid headers
					return $len;

				$headers[strtolower(trim($header[0]))][] = trim($header[1]);

				return $len;
			}
		);
		$result = json_decode(curl_exec($ch), true);
		$statusCode = curl_getInfo($ch, CURLINFO_HTTP_CODE);
		// $curlerr = "PUT extension $extension error: " . $statusCode . " - " . json_encode($post) . " - " . json_encode($result) . " - " . curl_error($ch) . " - Token: " . $access_token;
		$curlerr = "POST trunk error: " . $statusCode . " - " . json_encode($post) . " - " . json_encode($result) . " - " . curl_error($ch);
		curl_close($ch);

		// if ($statusCode == 201 && isset($result['secret']))
		if ($statusCode == 201 && isset($headers['location']))	{
			$loc = explode('/',$headers['location'][0]);
			return end($loc);
		} else {
			writelog($curlerr);
			throw new \Exception('Error creating trunk');
		}
}

function pbxapi_trunk_delete($access_token, $trunk, $isApplyChange = true)	{
	global $curlerr;

		$url = 'https://192.168.8.218/pbxapi/trunks/' . $trunk;
		if (!$isApplyChange)	$url .= ',0';
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Authorization: Bearer ' . $access_token)); 
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
		$result = curl_exec($ch);
		$statusCode = curl_getInfo($ch, CURLINFO_HTTP_CODE);
		$curlerr = "DELETE trunk $trunk error: $url - " . $statusCode . " - " . json_encode($result) . " - " . curl_error($ch);
		curl_close($ch);

		if ($result === false || $statusCode != 200)	{
			writelog($curlerr);
			return false;
		} 	else 
			return true;
}

function pbxapi_outboundroute_post($access_token, $post)	{
	global $curlerr;

		$url = 'https://192.168.8.218/pbxapi/outboundroutes';
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post));
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json', 'Authorization: Bearer ' . $access_token)); 
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
		curl_setopt($ch, CURLOPT_HEADERFUNCTION,
			function ($curl, $header) use (&$headers) {
				$len = strlen($header);
				$header = explode(':', $header, 2);
				if (count($header) < 2) // ignore invalid headers
					return $len;

				$headers[strtolower(trim($header[0]))][] = trim($header[1]);

				return $len;
			}
		);
		$result = json_decode(curl_exec($ch), true);
		$statusCode = curl_getInfo($ch, CURLINFO_HTTP_CODE);
		// $curlerr = "PUT extension $extension error: " . $statusCode . " - " . json_encode($post) . " - " . json_encode($result) . " - " . curl_error($ch) . " - Token: " . $access_token;
		$curlerr = "POST outboundroutes error: " . $statusCode . " - " . json_encode($post) . " - " . json_encode($result) . " - " . curl_error($ch);
		curl_close($ch);

		// if ($statusCode == 201 && isset($result['secret']))
		if ($statusCode == 201 && isset($headers['location']))	{
			$loc = explode('/',$headers['location'][0]);
			return end($loc);
		} else {
			writelog($curlerr);
			throw new \Exception('Error creating outbound route');
		}
}

function pbxapi_outboundroute_delete($access_token, $outboundroute, $isApplyChange = true)	{
	global $curlerr;

		$url = 'https://192.168.8.218/pbxapi/outboundroutes/' . $outboundroute;
		if (!$isApplyChange)	$url .= ',0';
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Authorization: Bearer ' . $access_token)); 
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
		$result = curl_exec($ch);
		$statusCode = curl_getInfo($ch, CURLINFO_HTTP_CODE);
		$curlerr = "DELETE outboundroute $outboundroute error: $url - " . $statusCode . " - " . json_encode($result) . " - " . curl_error($ch);
		curl_close($ch);

		if ($result === false || $statusCode != 200)	{
			writelog($curlerr);
			return false;
		} 	else 
			return true;
}

function generateRandomString($length = 10) {
	// Used for generating password if not supplied when inserting extensions

	$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	$charactersLength = strlen($characters);
	$randomString = '';
	for ($i = 0; $i < $length; $i++) {
		$randomString .= $characters[rand(0, $charactersLength - 1)];
	}
	return $randomString;
}

function sendalertmail($data)	{
	require("phpmailer/class.phpmailer.php"); // nạp thư viện gửi mail
	$mailer = new PHPMailer(); // khởi tạo đối tượng
	
	// Đăng nhập SMTP
	// Thiết lập SMTP Server
	$mailer->IsSMTP(); // gọi class smtp để đăng nhập

	// Thiết lập thông tin máy chủ mail
	$mailer->SMTPAuth 	= true; // gửi thông tin đăng nhập
	$mailer->SMTPSecure = "ssl";
	$mailer->Host       = "smtp.gmail.com";
	$mailer->Port       = 465;

	// Thông tin email client dùng để gửi
	$mailer->Username 	= 'htc.voip.alert@gmail.com'; // tên đăng nhập
	$mailer->Password 	= "Ww4dw112"; // mật khẩu
	$mailer->CharSet	="utf-8"; // bảng mã unicode
	$mailer->IsHTML(true); //Bật HTML không thích thì false

	// Chuẩn bị gửi thư nào
	$mailer->FromName 	= 'HTC P8218 - VNSale API'; // tên người gửi
	$mailer->From 		= 'htc.voip.alert@gmail.com'; // mail người gửi

	
	// $mailer->AddAddress($sms['email'], '');
	$mailer->AddAddress("ngoclongnguyen966", 'Nugyễn Ngọc Long');
	$mailer->AddAddress("nv.khoa.bk@gmail.com", 'Khoa Nguyễn Việt');

	$sub = "[8218-API] " . $data['subject'];
	$mailer->Subject = $sub;							// tiêu đề

	// Nội dung lá thư
	$mailbody 	= "<h3>Dear Admin!</h3><br><br>";
	$mailbody  .= $data['content'];
	$mailbody  .= "<br>Mọi chi tiết xin check log WSAPI.<br>Xin trân trọng cảm ơn!";
	
	$mailer->Body = $mailbody;							// nội dung

	// Gửi email
	if(!$mailer->Send())	{
		// Gửi không được, đưa ra thông báo lỗi
		writelog("Mailer error: " . $mailer->ErrorInfo . "\r\n");
	}
}

?>